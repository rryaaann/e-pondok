<?php
session_start();
require_once '../config/database.php';

// Cek login
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'guru') {
    header('Location: ../login.php');
    exit();
}

$success = '';
$error = '';

// Ambil data guru
try {
    $stmt = $pdo->prepare("SELECT * FROM guru WHERE id = (SELECT guru_id FROM users WHERE id = ?)");
    $stmt->execute([$_SESSION['user_id']]);
    $guru = $stmt->fetch();
    
    if (!$guru) {
        header('Location: ../login.php');
        exit();
    }
    
    // Proses input absensi
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        if (isset($_POST['action']) && $_POST['action'] == 'input_absensi') {
            try {
                $tanggal = $_POST['tanggal'];
                $kelas_id = $_POST['kelas_id'];
                $mata_pelajaran_id = $_POST['mata_pelajaran_id'];
                $santri_list = $_POST['santri'];
                
                // Hapus absensi yang sudah ada untuk tanggal dan mata pelajaran ini
                $stmt = $pdo->prepare("DELETE FROM absensi WHERE guru_id = ? AND mata_pelajaran_id = ? AND tanggal = ?");
                $stmt->execute([$guru['id'], $mata_pelajaran_id, $tanggal]);
                
                // Input absensi baru
                $stmt = $pdo->prepare("INSERT INTO absensi (santri_id, mata_pelajaran_id, guru_id, tanggal, status, keterangan) VALUES (?, ?, ?, ?, ?, ?)");
                
                foreach ($santri_list as $santri_id => $data) {
                    $stmt->execute([
                        $santri_id,
                        $mata_pelajaran_id,
                        $guru['id'],
                        $tanggal,
                        $data['status'],
                        $data['keterangan'] ?? ''
                    ]);
                }
                
                $success = 'Absensi berhasil disimpan!';
                
            } catch(PDOException $e) {
                $error = 'Error: ' . $e->getMessage();
            }
        }
    }
    
    // Ambil jadwal mengajar guru
    $stmt = $pdo->prepare("
        SELECT DISTINCT jp.kelas_id, jp.mata_pelajaran_id, k.nama_kelas, mp.nama_mapel, mp.kode_mapel
        FROM jadwal_pelajaran jp 
        JOIN kelas k ON jp.kelas_id = k.id 
        JOIN mata_pelajaran mp ON jp.mata_pelajaran_id = mp.id 
        WHERE jp.guru_id = ? 
        ORDER BY k.nama_kelas, mp.nama_mapel
    ");
    $stmt->execute([$guru['id']]);
    $jadwal_mengajar = $stmt->fetchAll();
    
    // Ambil data kelas dan mata pelajaran untuk dropdown
    $selected_kelas = $_GET['kelas_id'] ?? '';
    $selected_mapel = $_GET['mapel_id'] ?? '';
    $selected_tanggal = $_GET['tanggal'] ?? date('Y-m-d');
    
    // Jika ada kelas dan mapel yang dipilih, ambil data santri
    $santri_list = [];
    if ($selected_kelas && $selected_mapel) {
        $stmt = $pdo->prepare("
            SELECT s.*, 
                   a.status as absen_status, 
                   a.keterangan as absen_keterangan
            FROM santri s 
            LEFT JOIN absensi a ON s.id = a.santri_id 
                AND a.mata_pelajaran_id = ? 
                AND a.tanggal = ? 
                AND a.guru_id = ?
            WHERE s.kelas_id = ? AND s.status_santri = 'aktif'
            ORDER BY s.nama_lengkap
        ");
        $stmt->execute([$selected_mapel, $selected_tanggal, $guru['id'], $selected_kelas]);
        $santri_list = $stmt->fetchAll();
    }
    
} catch(PDOException $e) {
    $error = 'Error: ' . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Input Absensi - e-Pondok</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        .guru-container {
            display: flex;
            min-height: 100vh;
        }
        
        .sidebar {
            width: 250px;
            background: #28a745;
            color: white;
            position: fixed;
            height: 100vh;
            overflow-y: auto;
        }
        
        .sidebar-header {
            padding: 20px;
            text-align: center;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }
        
        .sidebar-title {
            font-size: 1.2rem;
            font-weight: 700;
        }
        
        .sidebar-menu {
            padding: 20px 0;
        }
        
        .menu-item {
            display: block;
            padding: 15px 20px;
            color: white;
            text-decoration: none;
            transition: all 0.3s ease;
            border-left: 3px solid transparent;
        }
        
        .menu-item:hover,
        .menu-item.active {
            background: rgba(255, 255, 255, 0.1);
            border-left-color: #ff6b6b;
        }
        
        .menu-item i {
            margin-right: 10px;
            width: 20px;
        }
        
        .main-content {
            flex: 1;
            margin-left: 250px;
            background: #f8f9fa;
        }
        
        .top-bar {
            background: white;
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .page-title {
            font-size: 1.5rem;
            font-weight: 600;
            color: #28a745;
        }
        
        .content-area {
            padding: 30px;
        }
        
        .filter-card {
            background: white;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            padding: 20px;
            margin-bottom: 30px;
        }
        
        .filter-title {
            font-size: 1.1rem;
            font-weight: 600;
            color: #333;
            margin-bottom: 15px;
        }
        
        .filter-form {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            align-items: end;
        }
        
        .form-group {
            margin-bottom: 0;
        }
        
        .form-label {
            display: block;
            margin-bottom: 5px;
            font-weight: 600;
            color: #333;
        }
        
        .form-control {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 0.9rem;
        }
        
        .form-control:focus {
            outline: none;
            border-color: #28a745;
        }
        
        .btn-filter {
            background: #28a745;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-weight: 600;
        }
        
        .absensi-card {
            background: white;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            overflow: hidden;
        }
        
        .card-header {
            padding: 20px;
            background: #f8f9fa;
            border-bottom: 1px solid #e9ecef;
        }
        
        .card-title {
            font-size: 1.2rem;
            font-weight: 600;
            color: #28a745;
        }
        
        .card-body {
            padding: 20px;
        }
        
        .absensi-table {
            width: 100%;
            border-collapse: collapse;
        }
        
        .absensi-table th,
        .absensi-table td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #e9ecef;
        }
        
        .absensi-table th {
            background: #f8f9fa;
            font-weight: 600;
            color: #333;
        }
        
        .status-select {
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 0.9rem;
        }
        
        .status-hadir { background: #d4edda; }
        .status-sakit { background: #fff3cd; }
        .status-izin { background: #cce5ff; }
        .status-alpha { background: #f8d7da; }
        
        .btn-save {
            background: #28a745;
            color: white;
            padding: 12px 30px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-weight: 600;
            font-size: 1rem;
            margin-top: 20px;
        }
        
        .btn-save:hover {
            background: #218838;
        }
        
        .alert {
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
        }
        
        .alert-success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        
        .alert-danger {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        
        .no-data {
            text-align: center;
            padding: 40px;
            color: #666;
        }
        
        .no-data i {
            font-size: 3rem;
            margin-bottom: 15px;
            color: #ddd;
        }
        
        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
                transition: transform 0.3s ease;
            }
            
            .sidebar.active {
                transform: translateX(0);
            }
            
            .main-content {
                margin-left: 0;
            }
            
            .filter-form {
                grid-template-columns: 1fr;
            }
            
            .absensi-table {
                font-size: 0.8rem;
            }
            
            .absensi-table th,
            .absensi-table td {
                padding: 8px;
            }
        }
    </style>
</head>
<body>
    <div class="guru-container">
        <!-- Sidebar -->
        <div class="sidebar" id="sidebar">
            <div class="sidebar-header">
                <h2 class="sidebar-title">e-Pondok</h2>
                <p>Guru Panel</p>
            </div>
            <div class="sidebar-menu">
                <a href="dashboard.php" class="menu-item">
                    <i class="fas fa-tachometer-alt"></i> Dashboard
                </a>
                <a href="jadwal.php" class="menu-item">
                    <i class="fas fa-calendar-alt"></i> Jadwal Mengajar
                </a>
                <a href="absensi.php" class="menu-item active">
                    <i class="fas fa-clipboard-check"></i> Absensi
                </a>
                <a href="nilai.php" class="menu-item">
                    <i class="fas fa-star"></i> Input Nilai
                </a>
                <a href="rapot.php" class="menu-item">
                    <i class="fas fa-file-alt"></i> e-Rapot
                </a>
                <a href="kegiatan.php" class="menu-item">
                    <i class="fas fa-tasks"></i> Kegiatan
                </a>
                <a href="profil.php" class="menu-item">
                    <i class="fas fa-user"></i> Profil
                </a>
            </div>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <div class="top-bar">
                <div class="page-title">Input Absensi Santri</div>
            </div>

            <div class="content-area">
                <?php if ($success): ?>
                    <div class="alert alert-success">
                        <i class="fas fa-check-circle"></i> <?php echo $success; ?>
                    </div>
                <?php endif; ?>
                
                <?php if ($error): ?>
                    <div class="alert alert-danger">
                        <i class="fas fa-exclamation-triangle"></i> <?php echo $error; ?>
                    </div>
                <?php endif; ?>

                <!-- Filter Card -->
                <div class="filter-card">
                    <h3 class="filter-title">Pilih Kelas dan Mata Pelajaran</h3>
                    <form method="GET" class="filter-form">
                        <div class="form-group">
                            <label class="form-label">Tanggal</label>
                            <input type="date" name="tanggal" class="form-control" value="<?php echo $selected_tanggal; ?>">
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label">Kelas</label>
                            <select name="kelas_id" class="form-control" required>
                                <option value="">Pilih Kelas</option>
                                <?php foreach ($jadwal_mengajar as $jadwal): ?>
                                <option value="<?php echo $jadwal['kelas_id']; ?>" 
                                        <?php echo ($selected_kelas == $jadwal['kelas_id']) ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($jadwal['nama_kelas']); ?>
                                </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label">Mata Pelajaran</label>
                            <select name="mapel_id" class="form-control" required>
                                <option value="">Pilih Mata Pelajaran</option>
                                <?php foreach ($jadwal_mengajar as $jadwal): ?>
                                <option value="<?php echo $jadwal['mata_pelajaran_id']; ?>" 
                                        <?php echo ($selected_mapel == $jadwal['mata_pelajaran_id']) ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($jadwal['nama_mapel']); ?>
                                </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <button type="submit" class="btn-filter">
                                <i class="fas fa-search"></i> Tampilkan
                            </button>
                        </div>
                    </form>
                </div>

                <!-- Absensi Card -->
                <?php if ($selected_kelas && $selected_mapel && !empty($santri_list)): ?>
                <div class="absensi-card">
                    <div class="card-header">
                        <h3 class="card-title">Input Absensi - <?php echo date('d/m/Y', strtotime($selected_tanggal)); ?></h3>
                    </div>
                    
                    <form method="POST">
                        <input type="hidden" name="action" value="input_absensi">
                        <input type="hidden" name="tanggal" value="<?php echo $selected_tanggal; ?>">
                        <input type="hidden" name="kelas_id" value="<?php echo $selected_kelas; ?>">
                        <input type="hidden" name="mata_pelajaran_id" value="<?php echo $selected_mapel; ?>">
                        
                        <div class="card-body">
                            <table class="absensi-table">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>NIS</th>
                                        <th>Nama Santri</th>
                                        <th>Status</th>
                                        <th>Keterangan</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($santri_list as $index => $santri): ?>
                                    <tr>
                                        <td><?php echo $index + 1; ?></td>
                                        <td><?php echo htmlspecialchars($santri['nis']); ?></td>
                                        <td><?php echo htmlspecialchars($santri['nama_lengkap']); ?></td>
                                        <td>
                                            <select name="santri[<?php echo $santri['id']; ?>][status]" class="status-select" required>
                                                <option value="hadir" <?php echo ($santri['absen_status'] == 'hadir') ? 'selected' : ''; ?>>Hadir</option>
                                                <option value="sakit" <?php echo ($santri['absen_status'] == 'sakit') ? 'selected' : ''; ?>>Sakit</option>
                                                <option value="izin" <?php echo ($santri['absen_status'] == 'izin') ? 'selected' : ''; ?>>Izin</option>
                                                <option value="alpha" <?php echo ($santri['absen_status'] == 'alpha') ? 'selected' : ''; ?>>Alpha</option>
                                            </select>
                                        </td>
                                        <td>
                                            <input type="text" name="santri[<?php echo $santri['id']; ?>][keterangan]" 
                                                   class="form-control" placeholder="Keterangan (opsional)"
                                                   value="<?php echo htmlspecialchars($santri['absen_keterangan'] ?? ''); ?>">
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                            
                            <button type="submit" class="btn-save">
                                <i class="fas fa-save"></i> Simpan Absensi
                            </button>
                        </div>
                    </form>
                </div>
                
                <?php elseif ($selected_kelas && $selected_mapel): ?>
                <div class="absensi-card">
                    <div class="no-data">
                        <i class="fas fa-users-slash"></i>
                        <h3>Tidak ada santri di kelas ini</h3>
                        <p>Silakan pilih kelas lain atau hubungi operator untuk menambahkan santri ke kelas ini.</p>
                    </div>
                </div>
                
                <?php else: ?>
                <div class="absensi-card">
                    <div class="no-data">
                        <i class="fas fa-clipboard-list"></i>
                        <h3>Pilih Kelas dan Mata Pelajaran</h3>
                        <p>Silakan pilih kelas dan mata pelajaran di atas untuk mulai input absensi.</p>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script src="../assets/js/script.js"></script>
    <script>
        // Auto-submit form when kelas or mapel changes
        document.querySelector('select[name="kelas_id"]').addEventListener('change', function() {
            if (this.value && document.querySelector('select[name="mapel_id"]').value) {
                this.form.submit();
            }
        });
        
        document.querySelector('select[name="mapel_id"]').addEventListener('change', function() {
            if (this.value && document.querySelector('select[name="kelas_id"]').value) {
                this.form.submit();
            }
        });
        
        // Status select styling
        document.querySelectorAll('.status-select').forEach(select => {
            select.addEventListener('change', function() {
                this.className = 'status-select status-' + this.value;
            });
        });
    </script>
</body>
</html> 