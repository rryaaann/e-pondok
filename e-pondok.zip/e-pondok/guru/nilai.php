<?php
session_start();
require_once '../config/database.php';

// Cek login
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'guru') {
    header('Location: ../login.php');
    exit();
}

$success = '';
$error = '';

// Ambil data guru
try {
    $stmt = $pdo->prepare("SELECT * FROM guru WHERE id = (SELECT guru_id FROM users WHERE id = ?)");
    $stmt->execute([$_SESSION['user_id']]);
    $guru = $stmt->fetch();
    
    if (!$guru) {
        header('Location: ../login.php');
        exit();
    }
    
    // Proses input nilai
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        if (isset($_POST['action']) && $_POST['action'] == 'input_nilai') {
            try {
                $semester = $_POST['semester'];
                $mata_pelajaran_id = $_POST['mata_pelajaran_id'];
                $nilai_list = $_POST['nilai'];
                
                foreach ($nilai_list as $santri_id => $data) {
                    // Hitung nilai akhir
                    $tugas_1 = floatval($data['tugas_1'] ?? 0);
                    $tugas_2 = floatval($data['tugas_2'] ?? 0);
                    $uts = floatval($data['uts'] ?? 0);
                    $uas = floatval($data['uas'] ?? 0);
                    
                    $nilai_akhir = ($tugas_1 * 0.2) + ($tugas_2 * 0.2) + ($uts * 0.3) + ($uas * 0.3);
                    
                    // Cek apakah nilai sudah ada
                    $stmt = $pdo->prepare("SELECT id FROM nilai WHERE santri_id = ? AND mata_pelajaran_id = ? AND semester = ?");
                    $stmt->execute([$santri_id, $mata_pelajaran_id, $semester]);
                    $existing = $stmt->fetch();
                    
                    if ($existing) {
                        // Update nilai yang sudah ada
                        $stmt = $pdo->prepare("UPDATE nilai SET tugas_1 = ?, tugas_2 = ?, uts = ?, uas = ?, nilai_akhir = ? WHERE id = ?");
                        $stmt->execute([$tugas_1, $tugas_2, $uts, $uas, $nilai_akhir, $existing['id']]);
                    } else {
                        // Insert nilai baru
                        $stmt = $pdo->prepare("INSERT INTO nilai (santri_id, mata_pelajaran_id, guru_id, semester, tugas_1, tugas_2, uts, uas, nilai_akhir) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
                        $stmt->execute([$santri_id, $mata_pelajaran_id, $guru['id'], $semester, $tugas_1, $tugas_2, $uts, $uas, $nilai_akhir]);
                    }
                }
                
                $success = 'Nilai berhasil disimpan!';
                
            } catch(PDOException $e) {
                $error = 'Error: ' . $e->getMessage();
            }
        }
    }
    
    // Ambil jadwal mengajar guru
    $stmt = $pdo->prepare("
        SELECT DISTINCT jp.kelas_id, jp.mata_pelajaran_id, k.nama_kelas, mp.nama_mapel, mp.kode_mapel
        FROM jadwal_pelajaran jp 
        JOIN kelas k ON jp.kelas_id = k.id 
        JOIN mata_pelajaran mp ON jp.mata_pelajaran_id = mp.id 
        WHERE jp.guru_id = ? 
        ORDER BY k.nama_kelas, mp.nama_mapel
    ");
    $stmt->execute([$guru['id']]);
    $jadwal_mengajar = $stmt->fetchAll();
    
    // Ambil data untuk dropdown
    $selected_kelas = $_GET['kelas_id'] ?? '';
    $selected_mapel = $_GET['mapel_id'] ?? '';
    $selected_semester = $_GET['semester'] ?? '1';
    
    // Jika ada kelas dan mapel yang dipilih, ambil data santri dan nilai
    $santri_list = [];
    if ($selected_kelas && $selected_mapel) {
        $stmt = $pdo->prepare("
            SELECT s.*, 
                   n.tugas_1, n.tugas_2, n.uts, n.uas, n.nilai_akhir
            FROM santri s 
            LEFT JOIN nilai n ON s.id = n.santri_id 
                AND n.mata_pelajaran_id = ? 
                AND n.semester = ?
            WHERE s.kelas_id = ? AND s.status_santri = 'aktif'
            ORDER BY s.nama_lengkap
        ");
        $stmt->execute([$selected_mapel, $selected_semester, $selected_kelas]);
        $santri_list = $stmt->fetchAll();
    }
    
} catch(PDOException $e) {
    $error = 'Error: ' . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Input Nilai - e-Pondok</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        .guru-container {
            display: flex;
            min-height: 100vh;
        }
        
        .sidebar {
            width: 250px;
            background: #28a745;
            color: white;
            position: fixed;
            height: 100vh;
            overflow-y: auto;
        }
        
        .sidebar-header {
            padding: 20px;
            text-align: center;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }
        
        .sidebar-title {
            font-size: 1.2rem;
            font-weight: 700;
        }
        
        .sidebar-menu {
            padding: 20px 0;
        }
        
        .menu-item {
            display: block;
            padding: 15px 20px;
            color: white;
            text-decoration: none;
            transition: all 0.3s ease;
            border-left: 3px solid transparent;
        }
        
        .menu-item:hover,
        .menu-item.active {
            background: rgba(255, 255, 255, 0.1);
            border-left-color: #ff6b6b;
        }
        
        .menu-item i {
            margin-right: 10px;
            width: 20px;
        }
        
        .main-content {
            flex: 1;
            margin-left: 250px;
            background: #f8f9fa;
        }
        
        .top-bar {
            background: white;
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .page-title {
            font-size: 1.5rem;
            font-weight: 600;
            color: #28a745;
        }
        
        .content-area {
            padding: 30px;
        }
        
        .filter-card {
            background: white;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            padding: 20px;
            margin-bottom: 30px;
        }
        
        .filter-title {
            font-size: 1.1rem;
            font-weight: 600;
            color: #333;
            margin-bottom: 15px;
        }
        
        .filter-form {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            align-items: end;
        }
        
        .form-group {
            margin-bottom: 0;
        }
        
        .form-label {
            display: block;
            margin-bottom: 5px;
            font-weight: 600;
            color: #333;
        }
        
        .form-control {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 0.9rem;
        }
        
        .form-control:focus {
            outline: none;
            border-color: #28a745;
        }
        
        .btn-filter {
            background: #28a745;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-weight: 600;
        }
        
        .nilai-card {
            background: white;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            overflow: hidden;
        }
        
        .card-header {
            padding: 20px;
            background: #f8f9fa;
            border-bottom: 1px solid #e9ecef;
        }
        
        .card-title {
            font-size: 1.2rem;
            font-weight: 600;
            color: #28a745;
        }
        
        .card-body {
            padding: 20px;
        }
        
        .nilai-table {
            width: 100%;
            border-collapse: collapse;
        }
        
        .nilai-table th,
        .nilai-table td {
            padding: 12px;
            text-align: center;
            border-bottom: 1px solid #e9ecef;
        }
        
        .nilai-table th {
            background: #f8f9fa;
            font-weight: 600;
            color: #333;
        }
        
        .nilai-table th:first-child,
        .nilai-table td:first-child {
            text-align: left;
        }
        
        .nilai-input {
            width: 60px;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 5px;
            text-align: center;
            font-size: 0.9rem;
        }
        
        .nilai-input:focus {
            outline: none;
            border-color: #28a745;
        }
        
        .nilai-akhir {
            font-weight: 600;
            color: #28a745;
        }
        
        .btn-save {
            background: #28a745;
            color: white;
            padding: 12px 30px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-weight: 600;
            font-size: 1rem;
            margin-top: 20px;
        }
        
        .btn-save:hover {
            background: #218838;
        }
        
        .alert {
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
        }
        
        .alert-success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        
        .alert-danger {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        
        .no-data {
            text-align: center;
            padding: 40px;
            color: #666;
        }
        
        .no-data i {
            font-size: 3rem;
            margin-bottom: 15px;
            color: #ddd;
        }
        
        .info-box {
            background: #e3f2fd;
            border: 1px solid #bbdefb;
            border-radius: 5px;
            padding: 15px;
            margin-bottom: 20px;
        }
        
        .info-box h4 {
            margin: 0 0 10px 0;
            color: #1976d2;
        }
        
        .info-box p {
            margin: 0;
            color: #424242;
        }
        
        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
                transition: transform 0.3s ease;
            }
            
            .sidebar.active {
                transform: translateX(0);
            }
            
            .main-content {
                margin-left: 0;
            }
            
            .filter-form {
                grid-template-columns: 1fr;
            }
            
            .nilai-table {
                font-size: 0.8rem;
            }
            
            .nilai-table th,
            .nilai-table td {
                padding: 8px;
            }
            
            .nilai-input {
                width: 50px;
                font-size: 0.8rem;
            }
        }
    </style>
</head>
<body>
    <div class="guru-container">
        <!-- Sidebar -->
        <div class="sidebar" id="sidebar">
            <div class="sidebar-header">
                <h2 class="sidebar-title">e-Pondok</h2>
                <p>Guru Panel</p>
            </div>
            <div class="sidebar-menu">
                <a href="dashboard.php" class="menu-item">
                    <i class="fas fa-tachometer-alt"></i> Dashboard
                </a>
                <a href="jadwal.php" class="menu-item">
                    <i class="fas fa-calendar-alt"></i> Jadwal Mengajar
                </a>
                <a href="absensi.php" class="menu-item">
                    <i class="fas fa-clipboard-check"></i> Absensi
                </a>
                <a href="nilai.php" class="menu-item active">
                    <i class="fas fa-star"></i> Input Nilai
                </a>
                <a href="rapot.php" class="menu-item">
                    <i class="fas fa-file-alt"></i> e-Rapot
                </a>
                <a href="kegiatan.php" class="menu-item">
                    <i class="fas fa-tasks"></i> Kegiatan
                </a>
                <a href="profil.php" class="menu-item">
                    <i class="fas fa-user"></i> Profil
                </a>
            </div>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <div class="top-bar">
                <div class="page-title">Input Nilai Santri</div>
            </div>

            <div class="content-area">
                <?php if ($success): ?>
                    <div class="alert alert-success">
                        <i class="fas fa-check-circle"></i> <?php echo $success; ?>
                    </div>
                <?php endif; ?>
                
                <?php if ($error): ?>
                    <div class="alert alert-danger">
                        <i class="fas fa-exclamation-triangle"></i> <?php echo $error; ?>
                    </div>
                <?php endif; ?>

                <!-- Info Box -->
                <div class="info-box">
                    <h4><i class="fas fa-info-circle"></i> Informasi Penilaian</h4>
                    <p><strong>Bobot Nilai:</strong> Tugas 1 (20%) + Tugas 2 (20%) + UTS (30%) + UAS (30%) = Nilai Akhir</p>
                    <p><strong>Rentang Nilai:</strong> 0 - 100</p>
                </div>

                <!-- Filter Card -->
                <div class="filter-card">
                    <h3 class="filter-title">Pilih Kelas dan Mata Pelajaran</h3>
                    <form method="GET" class="filter-form">
                        <div class="form-group">
                            <label class="form-label">Kelas</label>
                            <select name="kelas_id" class="form-control" required>
                                <option value="">Pilih Kelas</option>
                                <?php foreach ($jadwal_mengajar as $jadwal): ?>
                                <option value="<?php echo $jadwal['kelas_id']; ?>" 
                                        <?php echo ($selected_kelas == $jadwal['kelas_id']) ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($jadwal['nama_kelas']); ?>
                                </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label">Mata Pelajaran</label>
                            <select name="mapel_id" class="form-control" required>
                                <option value="">Pilih Mata Pelajaran</option>
                                <?php foreach ($jadwal_mengajar as $jadwal): ?>
                                <option value="<?php echo $jadwal['mata_pelajaran_id']; ?>" 
                                        <?php echo ($selected_mapel == $jadwal['mata_pelajaran_id']) ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($jadwal['nama_mapel']); ?>
                                </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label">Semester</label>
                            <select name="semester" class="form-control" required>
                                <option value="1" <?php echo ($selected_semester == '1') ? 'selected' : ''; ?>>Semester 1</option>
                                <option value="2" <?php echo ($selected_semester == '2') ? 'selected' : ''; ?>>Semester 2</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <button type="submit" class="btn-filter">
                                <i class="fas fa-search"></i> Tampilkan
                            </button>
                        </div>
                    </form>
                </div>

                <!-- Nilai Card -->
                <?php if ($selected_kelas && $selected_mapel && !empty($santri_list)): ?>
                <div class="nilai-card">
                    <div class="card-header">
                        <h3 class="card-title">Input Nilai - Semester <?php echo $selected_semester; ?></h3>
                    </div>
                    
                    <form method="POST">
                        <input type="hidden" name="action" value="input_nilai">
                        <input type="hidden" name="semester" value="<?php echo $selected_semester; ?>">
                        <input type="hidden" name="mata_pelajaran_id" value="<?php echo $selected_mapel; ?>">
                        
                        <div class="card-body">
                            <table class="nilai-table">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>NIS</th>
                                        <th>Nama Santri</th>
                                        <th>Tugas 1</th>
                                        <th>Tugas 2</th>
                                        <th>UTS</th>
                                        <th>UAS</th>
                                        <th>Nilai Akhir</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($santri_list as $index => $santri): ?>
                                    <tr>
                                        <td><?php echo $index + 1; ?></td>
                                        <td><?php echo htmlspecialchars($santri['nis']); ?></td>
                                        <td><?php echo htmlspecialchars($santri['nama_lengkap']); ?></td>
                                        <td>
                                            <input type="number" name="nilai[<?php echo $santri['id']; ?>][tugas_1]" 
                                                   class="nilai-input" min="0" max="100" step="0.01"
                                                   value="<?php echo $santri['tugas_1'] ?? ''; ?>"
                                                   onchange="hitungNilaiAkhir(this)">
                                        </td>
                                        <td>
                                            <input type="number" name="nilai[<?php echo $santri['id']; ?>][tugas_2]" 
                                                   class="nilai-input" min="0" max="100" step="0.01"
                                                   value="<?php echo $santri['tugas_2'] ?? ''; ?>"
                                                   onchange="hitungNilaiAkhir(this)">
                                        </td>
                                        <td>
                                            <input type="number" name="nilai[<?php echo $santri['id']; ?>][uts]" 
                                                   class="nilai-input" min="0" max="100" step="0.01"
                                                   value="<?php echo $santri['uts'] ?? ''; ?>"
                                                   onchange="hitungNilaiAkhir(this)">
                                        </td>
                                        <td>
                                            <input type="number" name="nilai[<?php echo $santri['id']; ?>][uas]" 
                                                   class="nilai-input" min="0" max="100" step="0.01"
                                                   value="<?php echo $santri['uas'] ?? ''; ?>"
                                                   onchange="hitungNilaiAkhir(this)">
                                        </td>
                                        <td>
                                            <span class="nilai-akhir" id="nilai-akhir-<?php echo $santri['id']; ?>">
                                                <?php echo $santri['nilai_akhir'] ? number_format($santri['nilai_akhir'], 2) : '-'; ?>
                                            </span>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                            
                            <button type="submit" class="btn-save">
                                <i class="fas fa-save"></i> Simpan Nilai
                            </button>
                        </div>
                    </form>
                </div>
                
                <?php elseif ($selected_kelas && $selected_mapel): ?>
                <div class="nilai-card">
                    <div class="no-data">
                        <i class="fas fa-users-slash"></i>
                        <h3>Tidak ada santri di kelas ini</h3>
                        <p>Silakan pilih kelas lain atau hubungi operator untuk menambahkan santri ke kelas ini.</p>
                    </div>
                </div>
                
                <?php else: ?>
                <div class="nilai-card">
                    <div class="no-data">
                        <i class="fas fa-star"></i>
                        <h3>Pilih Kelas dan Mata Pelajaran</h3>
                        <p>Silakan pilih kelas, mata pelajaran, dan semester di atas untuk mulai input nilai.</p>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script src="../assets/js/script.js"></script>
    <script>
        // Auto-submit form when kelas or mapel changes
        document.querySelector('select[name="kelas_id"]').addEventListener('change', function() {
            if (this.value && document.querySelector('select[name="mapel_id"]').value) {
                this.form.submit();
            }
        });
        
        document.querySelector('select[name="mapel_id"]').addEventListener('change', function() {
            if (this.value && document.querySelector('select[name="kelas_id"]').value) {
                this.form.submit();
            }
        });
        
        // Hitung nilai akhir otomatis
        function hitungNilaiAkhir(input) {
            const row = input.closest('tr');
            const santriId = row.querySelector('input').name.match(/\[(\d+)\]/)[1];
            
            const tugas1 = parseFloat(row.querySelector('input[name*="[tugas_1]"]').value) || 0;
            const tugas2 = parseFloat(row.querySelector('input[name*="[tugas_2]"]').value) || 0;
            const uts = parseFloat(row.querySelector('input[name*="[uts]"]').value) || 0;
            const uas = parseFloat(row.querySelector('input[name*="[uas]"]').value) || 0;
            
            const nilaiAkhir = (tugas1 * 0.2) + (tugas2 * 0.2) + (uts * 0.3) + (uas * 0.3);
            
            document.getElementById('nilai-akhir-' + santriId).textContent = nilaiAkhir.toFixed(2);
        }
        
        // Validasi input nilai
        document.querySelectorAll('.nilai-input').forEach(input => {
            input.addEventListener('input', function() {
                const value = parseFloat(this.value);
                if (value < 0) this.value = 0;
                if (value > 100) this.value = 100;
            });
        });
    </script>
</body>
</html> 