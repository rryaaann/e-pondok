<?php
session_start();
require_once '../config/database.php';

// Cek login
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'guru') {
    header('Location: ../login.php');
    exit();
}

// Ambil data guru
try {
    $stmt = $pdo->prepare("SELECT * FROM guru WHERE id = (SELECT guru_id FROM users WHERE id = ?)");
    $stmt->execute([$_SESSION['user_id']]);
    $guru = $stmt->fetch();
    
    if (!$guru) {
        header('Location: ../login.php');
        exit();
    }
    
    // Ambil jadwal hari ini
    $hari_ini = date('l');
    $hari_indonesia = [
        'Monday' => 'Senin',
        'Tuesday' => 'Selasa', 
        'Wednesday' => 'Rabu',
        'Thursday' => 'Kamis',
        'Friday' => 'Jumat',
        'Saturday' => 'Sabtu',
        'Sunday' => 'Minggu'
    ];
    $hari = $hari_indonesia[$hari_ini];
    
    $stmt = $pdo->prepare("
        SELECT jp.*, k.nama_kelas, mp.nama_mapel 
        FROM jadwal_pelajaran jp 
        JOIN kelas k ON jp.kelas_id = k.id 
        JOIN mata_pelajaran mp ON jp.mata_pelajaran_id = mp.id 
        WHERE jp.guru_id = ? AND jp.hari = ? 
        ORDER BY jp.jam_mulai
    ");
    $stmt->execute([$guru['id'], $hari]);
    $jadwal_hari_ini = $stmt->fetchAll();
    
    // Ambil statistik
    $stmt = $pdo->prepare("SELECT COUNT(DISTINCT jp.kelas_id) as total_kelas FROM jadwal_pelajaran jp WHERE jp.guru_id = ?");
    $stmt->execute([$guru['id']]);
    $total_kelas = $stmt->fetch()['total_kelas'];
    
    $stmt = $pdo->prepare("SELECT COUNT(DISTINCT jp.mata_pelajaran_id) as total_mapel FROM jadwal_pelajaran jp WHERE jp.guru_id = ?");
    $stmt->execute([$guru['id']]);
    $total_mapel = $stmt->fetch()['total_mapel'];
    
    // Ambil absensi hari ini
    $stmt = $pdo->prepare("
        SELECT COUNT(*) as total_absen 
        FROM absensi a 
        JOIN mata_pelajaran mp ON a.mata_pelajaran_id = mp.id 
        WHERE a.guru_id = ? AND a.tanggal = CURDATE()
    ");
    $stmt->execute([$guru['id']]);
    $total_absen_hari_ini = $stmt->fetch()['total_absen'];
    
    // Ambil nilai yang belum diinput
    $stmt = $pdo->prepare("
        SELECT COUNT(*) as nilai_pending 
        FROM nilai n 
        WHERE n.guru_id = ? AND n.nilai_akhir = 0
    ");
    $stmt->execute([$guru['id']]);
    $nilai_pending = $stmt->fetch()['nilai_pending'];
    
} catch(PDOException $e) {
    $error = "Error: " . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Guru - e-Pondok</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        .guru-container {
            display: flex;
            min-height: 100vh;
        }
        
        .sidebar {
            width: 250px;
            background: #28a745;
            color: white;
            position: fixed;
            height: 100vh;
            overflow-y: auto;
        }
        
        .sidebar-header {
            padding: 20px;
            text-align: center;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }
        
        .sidebar-title {
            font-size: 1.2rem;
            font-weight: 700;
        }
        
        .sidebar-menu {
            padding: 20px 0;
        }
        
        .menu-item {
            display: block;
            padding: 15px 20px;
            color: white;
            text-decoration: none;
            transition: all 0.3s ease;
            border-left: 3px solid transparent;
        }
        
        .menu-item:hover,
        .menu-item.active {
            background: rgba(255, 255, 255, 0.1);
            border-left-color: #ff6b6b;
        }
        
        .menu-item i {
            margin-right: 10px;
            width: 20px;
        }
        
        .main-content {
            flex: 1;
            margin-left: 250px;
            background: #f8f9fa;
        }
        
        .top-bar {
            background: white;
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .page-title {
            font-size: 1.5rem;
            font-weight: 600;
            color: #28a745;
        }
        
        .user-info {
            display: flex;
            align-items: center;
            gap: 15px;
        }
        
        .user-avatar {
            width: 40px;
            height: 40px;
            background: #28a745;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
        }
        
        .logout-btn {
            background: #dc3545;
            color: white;
            padding: 8px 15px;
            border-radius: 5px;
            text-decoration: none;
            font-size: 0.9rem;
        }
        
        .content-area {
            padding: 30px;
        }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .stat-card {
            background: white;
            padding: 25px;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease;
        }
        
        .stat-card:hover {
            transform: translateY(-5px);
        }
        
        .stat-icon {
            width: 60px;
            height: 60px;
            border-radius: 15px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            color: white;
            margin-bottom: 15px;
        }
        
        .stat-icon.green { background: #28a745; }
        .stat-icon.blue { background: #2c5aa0; }
        .stat-icon.orange { background: #ffc107; }
        .stat-icon.red { background: #dc3545; }
        
        .stat-number {
            font-size: 2rem;
            font-weight: 700;
            color: #333;
            margin-bottom: 5px;
        }
        
        .stat-label {
            color: #666;
            font-size: 0.9rem;
        }
        
        .dashboard-grid {
            display: grid;
            grid-template-columns: 2fr 1fr;
            gap: 30px;
        }
        
        .dashboard-card {
            background: white;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            overflow: hidden;
        }
        
        .card-header {
            padding: 20px;
            background: #f8f9fa;
            border-bottom: 1px solid #e9ecef;
        }
        
        .card-title {
            font-size: 1.2rem;
            font-weight: 600;
            color: #28a745;
        }
        
        .card-body {
            padding: 20px;
        }
        
        .jadwal-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px;
            border: 1px solid #e9ecef;
            border-radius: 10px;
            margin-bottom: 10px;
            transition: all 0.3s ease;
        }
        
        .jadwal-item:hover {
            border-color: #28a745;
            background: #f8f9fa;
        }
        
        .jadwal-info h4 {
            margin: 0 0 5px 0;
            color: #333;
        }
        
        .jadwal-info p {
            margin: 0;
            color: #666;
            font-size: 0.9rem;
        }
        
        .jadwal-time {
            text-align: right;
        }
        
        .jadwal-time .time {
            font-weight: 600;
            color: #28a745;
        }
        
        .jadwal-time .kelas {
            font-size: 0.9rem;
            color: #666;
        }
        
        .quick-actions {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            margin-top: 30px;
        }
        
        .action-btn {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 15px 20px;
            background: white;
            border: 2px solid #e9ecef;
            border-radius: 10px;
            text-decoration: none;
            color: #333;
            transition: all 0.3s ease;
        }
        
        .action-btn:hover {
            border-color: #28a745;
            color: #28a745;
            transform: translateY(-2px);
        }
        
        .action-btn i {
            font-size: 1.2rem;
        }
        
        .welcome-card {
            background: linear-gradient(135deg, #28a745 0%, #20c997 100%);
            color: white;
            padding: 30px;
            border-radius: 15px;
            margin-bottom: 30px;
        }
        
        .welcome-title {
            font-size: 1.5rem;
            font-weight: 600;
            margin-bottom: 10px;
        }
        
        .welcome-subtitle {
            opacity: 0.9;
        }
        
        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
                transition: transform 0.3s ease;
            }
            
            .sidebar.active {
                transform: translateX(0);
            }
            
            .main-content {
                margin-left: 0;
            }
            
            .dashboard-grid {
                grid-template-columns: 1fr;
            }
            
            .stats-grid {
                grid-template-columns: repeat(2, 1fr);
            }
        }
    </style>
</head>
<body>
    <div class="guru-container">
        <!-- Sidebar -->
        <div class="sidebar" id="sidebar">
            <div class="sidebar-header">
                <h2 class="sidebar-title">e-Pondok</h2>
                <p>Guru Panel</p>
            </div>
            <div class="sidebar-menu">
                <a href="dashboard.php" class="menu-item active">
                    <i class="fas fa-tachometer-alt"></i> Dashboard
                </a>
                <a href="jadwal.php" class="menu-item">
                    <i class="fas fa-calendar-alt"></i> Jadwal Mengajar
                </a>
                <a href="absensi.php" class="menu-item">
                    <i class="fas fa-clipboard-check"></i> Absensi
                </a>
                <a href="nilai.php" class="menu-item">
                    <i class="fas fa-star"></i> Input Nilai
                </a>
                <a href="rapot.php" class="menu-item">
                    <i class="fas fa-file-alt"></i> e-Rapot
                </a>
                <a href="kegiatan.php" class="menu-item">
                    <i class="fas fa-tasks"></i> Kegiatan
                </a>
                <a href="profil.php" class="menu-item">
                    <i class="fas fa-user"></i> Profil
                </a>
            </div>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <div class="top-bar">
                <div class="page-title">Dashboard Guru</div>
                <div class="user-info">
                    <div class="user-avatar">
                        <i class="fas fa-chalkboard-teacher"></i>
                    </div>
                    <div>
                        <div><?php echo htmlspecialchars($guru['nama_lengkap']); ?></div>
                        <small>Guru</small>
                    </div>
                    <a href="../logout.php" class="logout-btn">
                        <i class="fas fa-sign-out-alt"></i> Logout
                    </a>
                </div>
            </div>

            <div class="content-area">
                <!-- Welcome Card -->
                <div class="welcome-card">
                    <h2 class="welcome-title">Selamat Datang, <?php echo htmlspecialchars($guru['nama_lengkap']); ?>!</h2>
                    <p class="welcome-subtitle">Mata Pelajaran: <?php echo htmlspecialchars($guru['mata_pelajaran']); ?></p>
                </div>

                <!-- Statistics Cards -->
                <div class="stats-grid">
                    <div class="stat-card">
                        <div class="stat-icon green">
                            <i class="fas fa-school"></i>
                        </div>
                        <div class="stat-number"><?php echo $total_kelas; ?></div>
                        <div class="stat-label">Kelas yang Diampu</div>
                    </div>
                    
                    <div class="stat-card">
                        <div class="stat-icon blue">
                            <i class="fas fa-book"></i>
                        </div>
                        <div class="stat-number"><?php echo $total_mapel; ?></div>
                        <div class="stat-label">Mata Pelajaran</div>
                    </div>
                    
                    <div class="stat-card">
                        <div class="stat-icon orange">
                            <i class="fas fa-clipboard-check"></i>
                        </div>
                        <div class="stat-number"><?php echo $total_absen_hari_ini; ?></div>
                        <div class="stat-label">Absensi Hari Ini</div>
                    </div>
                    
                    <div class="stat-card">
                        <div class="stat-icon red">
                            <i class="fas fa-star"></i>
                        </div>
                        <div class="stat-number"><?php echo $nilai_pending; ?></div>
                        <div class="stat-label">Nilai Belum Diinput</div>
                    </div>
                </div>

                <!-- Dashboard Grid -->
                <div class="dashboard-grid">
                    <div class="dashboard-card">
                        <div class="card-header">
                            <h3 class="card-title">Jadwal Mengajar Hari Ini (<?php echo $hari; ?>)</h3>
                        </div>
                        <div class="card-body">
                            <?php if (empty($jadwal_hari_ini)): ?>
                                <p style="text-align: center; color: #666; padding: 20px;">
                                    <i class="fas fa-calendar-times"></i> Tidak ada jadwal mengajar hari ini
                                </p>
                            <?php else: ?>
                                <?php foreach ($jadwal_hari_ini as $jadwal): ?>
                                <div class="jadwal-item">
                                    <div class="jadwal-info">
                                        <h4><?php echo htmlspecialchars($jadwal['nama_mapel']); ?></h4>
                                        <p>Kelas: <?php echo htmlspecialchars($jadwal['nama_kelas']); ?></p>
                                    </div>
                                    <div class="jadwal-time">
                                        <div class="time">
                                            <?php echo date('H:i', strtotime($jadwal['jam_mulai'])); ?> - 
                                            <?php echo date('H:i', strtotime($jadwal['jam_selesai'])); ?>
                                        </div>
                                        <div class="kelas"><?php echo htmlspecialchars($jadwal['nama_kelas']); ?></div>
                                    </div>
                                </div>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="dashboard-card">
                        <div class="card-header">
                            <h3 class="card-title">Menu Cepat</h3>
                        </div>
                        <div class="card-body">
                            <div style="display: flex; flex-direction: column; gap: 10px;">
                                <a href="absensi.php" style="display: flex; align-items: center; gap: 10px; padding: 10px; background: #f8f9fa; border-radius: 8px; text-decoration: none; color: #333;">
                                    <i class="fas fa-clipboard-check" style="color: #28a745;"></i>
                                    <span>Input Absensi</span>
                                </a>
                                
                                <a href="nilai.php" style="display: flex; align-items: center; gap: 10px; padding: 10px; background: #f8f9fa; border-radius: 8px; text-decoration: none; color: #333;">
                                    <i class="fas fa-star" style="color: #ffc107;"></i>
                                    <span>Input Nilai</span>
                                </a>
                                
                                <a href="rapot.php" style="display: flex; align-items: center; gap: 10px; padding: 10px; background: #f8f9fa; border-radius: 8px; text-decoration: none; color: #333;">
                                    <i class="fas fa-file-alt" style="color: #2c5aa0;"></i>
                                    <span>e-Rapot</span>
                                </a>
                                
                                <a href="kegiatan.php" style="display: flex; align-items: center; gap: 10px; padding: 10px; background: #f8f9fa; border-radius: 8px; text-decoration: none; color: #333;">
                                    <i class="fas fa-tasks" style="color: #dc3545;"></i>
                                    <span>Kegiatan</span>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Quick Actions -->
                <div class="quick-actions">
                    <a href="absensi.php" class="action-btn">
                        <i class="fas fa-clipboard-check"></i>
                        <div>
                            <div>Input Absensi</div>
                            <small>Absensi santri per pertemuan</small>
                        </div>
                    </a>
                    
                    <a href="nilai.php" class="action-btn">
                        <i class="fas fa-star"></i>
                        <div>
                            <div>Input Nilai</div>
                            <small>Input nilai tugas dan ujian</small>
                        </div>
                    </a>
                    
                    <a href="rapot.php" class="action-btn">
                        <i class="fas fa-file-alt"></i>
                        <div>
                            <div>e-Rapot</div>
                            <small>Kelola rapot santri</small>
                        </div>
                    </a>
                    
                    <a href="kegiatan.php" class="action-btn">
                        <i class="fas fa-tasks"></i>
                        <div>
                            <div>Kegiatan</div>
                            <small>Input kegiatan dan tugas</small>
                        </div>
                    </a>
                    
                    <a href="jadwal.php" class="action-btn">
                        <i class="fas fa-calendar-alt"></i>
                        <div>
                            <div>Jadwal Mengajar</div>
                            <small>Lihat jadwal mengajar</small>
                        </div>
                    </a>
                    
                    <a href="profil.php" class="action-btn">
                        <i class="fas fa-user"></i>
                        <div>
                            <div>Profil</div>
                            <small>Update data profil</small>
                        </div>
                    </a>
                </div>
            </div>
        </div>
    </div>

    <script src="../assets/js/script.js"></script>
</body>
</html> 