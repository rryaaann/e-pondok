<?php
session_start();
require_once '../config/database.php';

// Cek login
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'guru') {
    header('Location: ../login.php');
    exit();
}

$success = '';
$error = '';

// Ambil data guru
try {
    $stmt = $pdo->prepare("SELECT * FROM guru WHERE id = (SELECT guru_id FROM users WHERE id = ?)");
    $stmt->execute([$_SESSION['user_id']]);
    $guru = $stmt->fetch();
    
    if (!$guru) {
        header('Location: ../login.php');
        exit();
    }
    
    // Ambil jadwal mengajar
    $stmt = $pdo->prepare("
        SELECT jp.*, k.nama_kelas, mp.nama_mapel, mp.kode_mapel
        FROM jadwal_pelajaran jp 
        JOIN kelas k ON jp.kelas_id = k.id 
        JOIN mata_pelajaran mp ON jp.mata_pelajaran_id = mp.id 
        WHERE jp.guru_id = ? 
        ORDER BY FIELD(jp.hari, 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu', 'Minggu'), jp.jam_mulai
    ");
    $stmt->execute([$guru['id']]);
    $jadwal_mengajar = $stmt->fetchAll();
    
    // Kelompokkan jadwal berdasarkan hari
    $jadwal_per_hari = [];
    $hari_list = ['Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu', 'Minggu'];
    
    foreach ($hari_list as $hari) {
        $jadwal_per_hari[$hari] = array_filter($jadwal_mengajar, function($jadwal) use ($hari) {
            return $jadwal['hari'] == $hari;
        });
    }
    
    // Ambil jadwal kegiatan pondok
    $stmt = $pdo->query("
        SELECT * FROM jadwal_kegiatan 
        ORDER BY FIELD(hari, 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu', 'Minggu'), jam_mulai
    ");
    $jadwal_kegiatan = $stmt->fetchAll();
    
    // Kelompokkan kegiatan berdasarkan hari
    $kegiatan_per_hari = [];
    foreach ($hari_list as $hari) {
        $kegiatan_per_hari[$hari] = array_filter($jadwal_kegiatan, function($kegiatan) use ($hari) {
            return $kegiatan['hari'] == $hari;
        });
    }
    
} catch(PDOException $e) {
    $error = 'Error: ' . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Jadwal Mengajar - e-Pondok</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        .guru-container {
            display: flex;
            min-height: 100vh;
        }
        
        .sidebar {
            width: 250px;
            background: #28a745;
            color: white;
            position: fixed;
            height: 100vh;
            overflow-y: auto;
        }
        
        .sidebar-header {
            padding: 20px;
            text-align: center;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }
        
        .sidebar-title {
            font-size: 1.2rem;
            font-weight: 700;
        }
        
        .sidebar-menu {
            padding: 20px 0;
        }
        
        .menu-item {
            display: block;
            padding: 15px 20px;
            color: white;
            text-decoration: none;
            transition: all 0.3s ease;
            border-left: 3px solid transparent;
        }
        
        .menu-item:hover,
        .menu-item.active {
            background: rgba(255, 255, 255, 0.1);
            border-left-color: #ff6b6b;
        }
        
        .menu-item i {
            margin-right: 10px;
            width: 20px;
        }
        
        .main-content {
            flex: 1;
            margin-left: 250px;
            background: #f8f9fa;
        }
        
        .top-bar {
            background: white;
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .page-title {
            font-size: 1.5rem;
            font-weight: 600;
            color: #28a745;
        }
        
        .content-area {
            padding: 30px;
        }
        
        .jadwal-grid {
            display: grid;
            grid-template-columns: 2fr 1fr;
            gap: 30px;
        }
        
        .jadwal-card {
            background: white;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            overflow: hidden;
        }
        
        .card-header {
            padding: 20px;
            background: #f8f9fa;
            border-bottom: 1px solid #e9ecef;
        }
        
        .card-title {
            font-size: 1.2rem;
            font-weight: 600;
            color: #28a745;
        }
        
        .card-body {
            padding: 20px;
        }
        
        .hari-section {
            margin-bottom: 30px;
        }
        
        .hari-title {
            font-size: 1.1rem;
            font-weight: 600;
            color: #333;
            margin-bottom: 15px;
            padding: 10px 15px;
            background: #e9ecef;
            border-radius: 5px;
        }
        
        .jadwal-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px;
            border: 1px solid #e9ecef;
            border-radius: 8px;
            margin-bottom: 10px;
            transition: all 0.3s ease;
        }
        
        .jadwal-item:hover {
            border-color: #28a745;
            background: #f8f9fa;
        }
        
        .jadwal-info h4 {
            margin: 0 0 5px 0;
            color: #333;
            font-size: 1rem;
        }
        
        .jadwal-info p {
            margin: 0;
            color: #666;
            font-size: 0.9rem;
        }
        
        .jadwal-time {
            text-align: right;
        }
        
        .jadwal-time .time {
            font-weight: 600;
            color: #28a745;
            font-size: 1rem;
        }
        
        .jadwal-time .kelas {
            font-size: 0.9rem;
            color: #666;
        }
        
        .kegiatan-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 12px;
            border: 1px solid #e9ecef;
            border-radius: 8px;
            margin-bottom: 8px;
            background: #f8f9fa;
        }
        
        .kegiatan-info h4 {
            margin: 0 0 3px 0;
            color: #333;
            font-size: 0.9rem;
        }
        
        .kegiatan-info p {
            margin: 0;
            color: #666;
            font-size: 0.8rem;
        }
        
        .kegiatan-time {
            text-align: right;
        }
        
        .kegiatan-time .time {
            font-weight: 600;
            color: #6c757d;
            font-size: 0.9rem;
        }
        
        .today-highlight {
            background: #e3f2fd !important;
            border-color: #bbdefb !important;
        }
        
        .today-highlight .hari-title {
            background: #1976d2 !important;
            color: white !important;
        }
        
        .no-jadwal {
            text-align: center;
            padding: 20px;
            color: #666;
        }
        
        .no-jadwal i {
            font-size: 2rem;
            margin-bottom: 10px;
            color: #ddd;
        }
        
        .alert {
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
        }
        
        .alert-danger {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        
        .info-box {
            background: #e3f2fd;
            border: 1px solid #bbdefb;
            border-radius: 5px;
            padding: 15px;
            margin-bottom: 20px;
        }
        
        .info-box h4 {
            margin: 0 0 10px 0;
            color: #1976d2;
        }
        
        .info-box p {
            margin: 0;
            color: #424242;
        }
        
        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
                transition: transform 0.3s ease;
            }
            
            .sidebar.active {
                transform: translateX(0);
            }
            
            .main-content {
                margin-left: 0;
            }
            
            .jadwal-grid {
                grid-template-columns: 1fr;
            }
            
            .jadwal-item {
                flex-direction: column;
                align-items: flex-start;
            }
            
            .jadwal-time {
                text-align: left;
                margin-top: 10px;
            }
        }
    </style>
</head>
<body>
    <div class="guru-container">
        <!-- Sidebar -->
        <div class="sidebar" id="sidebar">
            <div class="sidebar-header">
                <h2 class="sidebar-title">e-Pondok</h2>
                <p>Guru Panel</p>
            </div>
            <div class="sidebar-menu">
                <a href="dashboard.php" class="menu-item">
                    <i class="fas fa-tachometer-alt"></i> Dashboard
                </a>
                <a href="jadwal.php" class="menu-item active">
                    <i class="fas fa-calendar-alt"></i> Jadwal Mengajar
                </a>
                <a href="absensi.php" class="menu-item">
                    <i class="fas fa-clipboard-check"></i> Absensi
                </a>
                <a href="nilai.php" class="menu-item">
                    <i class="fas fa-star"></i> Input Nilai
                </a>
                <a href="rapot.php" class="menu-item">
                    <i class="fas fa-file-alt"></i> e-Rapot
                </a>
                <a href="kegiatan.php" class="menu-item">
                    <i class="fas fa-tasks"></i> Kegiatan
                </a>
                <a href="profil.php" class="menu-item">
                    <i class="fas fa-user"></i> Profil
                </a>
            </div>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <div class="top-bar">
                <div class="page-title">Jadwal Mengajar</div>
            </div>

            <div class="content-area">
                <?php if ($error): ?>
                    <div class="alert alert-danger">
                        <i class="fas fa-exclamation-triangle"></i> <?php echo $error; ?>
                    </div>
                <?php endif; ?>

                <!-- Info Box -->
                <div class="info-box">
                    <h4><i class="fas fa-info-circle"></i> Informasi Jadwal</h4>
                    <p><strong>Guru:</strong> <?php echo htmlspecialchars($guru['nama_lengkap']); ?></p>
                    <p><strong>Mata Pelajaran:</strong> <?php echo htmlspecialchars($guru['mata_pelajaran']); ?></p>
                    <p><strong>Total Jadwal:</strong> <?php echo count($jadwal_mengajar); ?> sesi mengajar per minggu</p>
                </div>

                <div class="jadwal-grid">
                    <!-- Jadwal Mengajar -->
                    <div class="jadwal-card">
                        <div class="card-header">
                            <h3 class="card-title">Jadwal Mengajar</h3>
                        </div>
                        <div class="card-body">
                            <?php 
                            $hari_ini = date('l');
                            $hari_indonesia = [
                                'Monday' => 'Senin',
                                'Tuesday' => 'Selasa', 
                                'Wednesday' => 'Rabu',
                                'Thursday' => 'Kamis',
                                'Friday' => 'Jumat',
                                'Saturday' => 'Sabtu',
                                'Sunday' => 'Minggu'
                            ];
                            $hari_sekarang = $hari_indonesia[$hari_ini];
                            
                            $has_jadwal = false;
                            foreach ($jadwal_per_hari as $hari => $jadwal_list): 
                                if (!empty($jadwal_list)) {
                                    $has_jadwal = true;
                                    $is_today = ($hari == $hari_sekarang);
                            ?>
                            <div class="hari-section <?php echo $is_today ? 'today-highlight' : ''; ?>">
                                <div class="hari-title">
                                    <?php echo $hari; ?>
                                    <?php if ($is_today): ?>
                                    <span style="background: #28a745; color: white; padding: 2px 8px; border-radius: 10px; font-size: 0.8rem; margin-left: 10px;">Hari Ini</span>
                                    <?php endif; ?>
                                </div>
                                
                                <?php foreach ($jadwal_list as $jadwal): ?>
                                <div class="jadwal-item">
                                    <div class="jadwal-info">
                                        <h4><?php echo htmlspecialchars($jadwal['nama_mapel']); ?></h4>
                                        <p>Kelas: <?php echo htmlspecialchars($jadwal['nama_kelas']); ?></p>
                                    </div>
                                    <div class="jadwal-time">
                                        <div class="time">
                                            <?php echo date('H:i', strtotime($jadwal['jam_mulai'])); ?> - 
                                            <?php echo date('H:i', strtotime($jadwal['jam_selesai'])); ?>
                                        </div>
                                        <div class="kelas"><?php echo htmlspecialchars($jadwal['nama_kelas']); ?></div>
                                    </div>
                                </div>
                                <?php endforeach; ?>
                            </div>
                            <?php 
                                }
                            endforeach; 
                            
                            if (!$has_jadwal):
                            ?>
                            <div class="no-jadwal">
                                <i class="fas fa-calendar-times"></i>
                                <h3>Belum ada jadwal mengajar</h3>
                                <p>Silakan hubungi operator untuk mengatur jadwal mengajar Anda.</p>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>

                    <!-- Jadwal Kegiatan Pondok -->
                    <div class="jadwal-card">
                        <div class="card-header">
                            <h3 class="card-title">Jadwal Kegiatan Pondok</h3>
                        </div>
                        <div class="card-body">
                            <?php 
                            $has_kegiatan = false;
                            foreach ($kegiatan_per_hari as $hari => $kegiatan_list): 
                                if (!empty($kegiatan_list)) {
                                    $has_kegiatan = true;
                                    $is_today = ($hari == $hari_sekarang);
                            ?>
                            <div class="hari-section <?php echo $is_today ? 'today-highlight' : ''; ?>">
                                <div class="hari-title">
                                    <?php echo $hari; ?>
                                    <?php if ($is_today): ?>
                                    <span style="background: #28a745; color: white; padding: 2px 8px; border-radius: 10px; font-size: 0.8rem; margin-left: 10px;">Hari Ini</span>
                                    <?php endif; ?>
                                </div>
                                
                                <?php foreach ($kegiatan_list as $kegiatan): ?>
                                <div class="kegiatan-item">
                                    <div class="kegiatan-info">
                                        <h4><?php echo htmlspecialchars($kegiatan['nama_kegiatan']); ?></h4>
                                        <p><?php echo htmlspecialchars($kegiatan['deskripsi'] ?? ''); ?></p>
                                    </div>
                                    <div class="kegiatan-time">
                                        <div class="time">
                                            <?php echo date('H:i', strtotime($kegiatan['jam_mulai'])); ?> - 
                                            <?php echo date('H:i', strtotime($kegiatan['jam_selesai'])); ?>
                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; ?>
                            </div>
                            <?php 
                                }
                            endforeach; 
                            
                            if (!$has_kegiatan):
                            ?>
                            <div class="no-jadwal">
                                <i class="fas fa-calendar-times"></i>
                                <h3>Belum ada jadwal kegiatan</h3>
                                <p>Jadwal kegiatan pondok belum diatur.</p>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="../assets/js/script.js"></script>
</body>
</html> 