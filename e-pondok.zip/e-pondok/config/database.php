<?php
// Konfigurasi Database e-Pondok
$host = 'localhost';
$username = 'root';
$password = '';
$database = 'e_pondok';

// Membuat koneksi
try {
    $pdo = new PDO("mysql:host=$host;dbname=$database;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch(PDOException $e) {
    die("Koneksi database gagal: " . $e->getMessage());
}

// Fungsi untuk membuat database jika belum ada
function createDatabase() {
    global $host, $username, $password, $database;
    
    try {
        $pdo = new PDO("mysql:host=$host", $username, $password);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        
        // Buat database jika belum ada
        $pdo->exec("CREATE DATABASE IF NOT EXISTS `$database` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
        
        return true;
    } catch(PDOException $e) {
        die("Error creating database: " . $e->getMessage());
    }
}

// Fungsi untuk membuat tabel-tabel
function createTables() {
    global $pdo;
    
    // Tabel users (untuk operator dan guru)
    $sql_users = "CREATE TABLE IF NOT EXISTS users (
        id INT AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(50) UNIQUE NOT NULL,
        password VARCHAR(255) NOT NULL,
        role ENUM('operator', 'guru') NOT NULL,
        nama_lengkap VARCHAR(100) NOT NULL,
        email VARCHAR(100),
        no_hp VARCHAR(15),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    )";
    
    // Tabel guru
    $sql_guru = "CREATE TABLE IF NOT EXISTS guru (
        id INT AUTO_INCREMENT PRIMARY KEY,
        nip VARCHAR(20) UNIQUE,
        nama_lengkap VARCHAR(100) NOT NULL,
        tempat_lahir VARCHAR(50),
        tanggal_lahir DATE,
        jenis_kelamin ENUM('L', 'P') NOT NULL,
        alamat TEXT,
        no_hp VARCHAR(15),
        email VARCHAR(100),
        pendidikan_terakhir VARCHAR(50),
        mata_pelajaran VARCHAR(100),
        status ENUM('aktif', 'nonaktif') DEFAULT 'aktif',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )";
    
    // Tabel santri
    $sql_santri = "CREATE TABLE IF NOT EXISTS santri (
        id INT AUTO_INCREMENT PRIMARY KEY,
        nis VARCHAR(20) UNIQUE,
        nisn VARCHAR(20),
        nik VARCHAR(16),
        nama_lengkap VARCHAR(100) NOT NULL,
        tempat_lahir VARCHAR(50),
        tanggal_lahir DATE,
        jenis_kelamin ENUM('L', 'P') NOT NULL,
        alamat TEXT,
        jenis_santri ENUM('Pondok Kitab', 'Qurani') NOT NULL,
        jenjang_pendidikan ENUM('SMP', 'SMK', 'Tidak mengikuti') NOT NULL,
        kamar VARCHAR(50),
        kelas_id INT,
        nama_wali VARCHAR(100),
        no_hp_wali VARCHAR(15),
        status_pendaftaran ENUM('pending', 'diterima', 'ditolak') DEFAULT 'pending',
        status_santri ENUM('aktif', 'nonaktif') DEFAULT 'aktif',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )";
    
    // Tabel kelas
    $sql_kelas = "CREATE TABLE IF NOT EXISTS kelas (
        id INT AUTO_INCREMENT PRIMARY KEY,
        nama_kelas VARCHAR(20) NOT NULL,
        jenjang ENUM('SMP', 'SMK') NOT NULL,
        wali_kelas_id INT,
        kapasitas INT DEFAULT 30,
        tahun_ajaran VARCHAR(10),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )";
    
    // Tabel mata_pelajaran
    $sql_mapel = "CREATE TABLE IF NOT EXISTS mata_pelajaran (
        id INT AUTO_INCREMENT PRIMARY KEY,
        kode_mapel VARCHAR(10) UNIQUE NOT NULL,
        nama_mapel VARCHAR(100) NOT NULL,
        jenjang ENUM('SMP', 'SMK') NOT NULL,
        guru_id INT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )";
    
    // Tabel jadwal_pelajaran
    $sql_jadwal = "CREATE TABLE IF NOT EXISTS jadwal_pelajaran (
        id INT AUTO_INCREMENT PRIMARY KEY,
        kelas_id INT NOT NULL,
        mata_pelajaran_id INT NOT NULL,
        guru_id INT NOT NULL,
        hari ENUM('Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu', 'Minggu') NOT NULL,
        jam_mulai TIME NOT NULL,
        jam_selesai TIME NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )";
    
    // Tabel jadwal_kegiatan
    $sql_kegiatan = "CREATE TABLE IF NOT EXISTS jadwal_kegiatan (
        id INT AUTO_INCREMENT PRIMARY KEY,
        nama_kegiatan VARCHAR(100) NOT NULL,
        hari ENUM('Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu', 'Minggu') NOT NULL,
        jam_mulai TIME NOT NULL,
        jam_selesai TIME NOT NULL,
        deskripsi TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )";
    
    // Tabel absensi
    $sql_absensi = "CREATE TABLE IF NOT EXISTS absensi (
        id INT AUTO_INCREMENT PRIMARY KEY,
        santri_id INT NOT NULL,
        mata_pelajaran_id INT NOT NULL,
        guru_id INT NOT NULL,
        tanggal DATE NOT NULL,
        status ENUM('hadir', 'sakit', 'izin', 'alpha') NOT NULL,
        keterangan TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )";
    
    // Tabel nilai
    $sql_nilai = "CREATE TABLE IF NOT EXISTS nilai (
        id INT AUTO_INCREMENT PRIMARY KEY,
        santri_id INT NOT NULL,
        mata_pelajaran_id INT NOT NULL,
        guru_id INT NOT NULL,
        semester ENUM('1', '2') NOT NULL,
        tugas_1 DECIMAL(5,2) DEFAULT 0,
        tugas_2 DECIMAL(5,2) DEFAULT 0,
        uts DECIMAL(5,2) DEFAULT 0,
        uas DECIMAL(5,2) DEFAULT 0,
        nilai_akhir DECIMAL(5,2) DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    )";
    
    // Tabel pendaftaran
    $sql_pendaftaran = "CREATE TABLE IF NOT EXISTS pendaftaran (
        id INT AUTO_INCREMENT PRIMARY KEY,
        nama_lengkap VARCHAR(100) NOT NULL,
        nik VARCHAR(16),
        nisn VARCHAR(20),
        tempat_lahir VARCHAR(50),
        tanggal_lahir DATE,
        jenis_kelamin ENUM('L', 'P') NOT NULL,
        alamat TEXT,
        jenis_santri ENUM('Pondok Kitab', 'Qurani') NOT NULL,
        jenjang_pendidikan ENUM('SMP', 'SMK', 'Tidak mengikuti') NOT NULL,
        nama_wali VARCHAR(100),
        no_hp_wali VARCHAR(15),
        file_ijazah VARCHAR(255),
        file_kk VARCHAR(255),
        status ENUM('pending', 'diterima', 'ditolak') DEFAULT 'pending',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )";
    
    // Tabel kamar
    $sql_kamar = "CREATE TABLE IF NOT EXISTS kamar (
        id INT AUTO_INCREMENT PRIMARY KEY,
        nama_kamar VARCHAR(50) NOT NULL,
        kapasitas INT DEFAULT 20,
        jumlah_penghuni INT DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )";
    
    try {
        $pdo->exec($sql_users);
        $pdo->exec($sql_guru);
        $pdo->exec($sql_santri);
        $pdo->exec($sql_kelas);
        $pdo->exec($sql_mapel);
        $pdo->exec($sql_jadwal);
        $pdo->exec($sql_kegiatan);
        $pdo->exec($sql_absensi);
        $pdo->exec($sql_nilai);
        $pdo->exec($sql_pendaftaran);
        $pdo->exec($sql_kamar);
        
        // Insert data awal
        insertInitialData();
        
        return true;
    } catch(PDOException $e) {
        die("Error creating tables: " . $e->getMessage());
    }
}

// Fungsi untuk insert data awal
function insertInitialData() {
    global $pdo;
    
    // Insert operator default
    $operator_password = password_hash('operator123', PASSWORD_DEFAULT);
    $sql_operator = "INSERT IGNORE INTO users (username, password, role, nama_lengkap, email) 
                     VALUES ('operator', '$operator_password', 'operator', 'Administrator', 'admin@epondok.id')";
    
    // Insert kamar-kamar
    $kamar_list = [
        'AMPEL', 'MUTAMAKIN', 'IBNU SHOLAH', 'SUNAN GUNUNG JATI', 
        'MUBAROK', 'ALFADLU', 'SUNAN MURIA', 'AZZAHRO', 'QURANI'
    ];
    
    $sql_kamar = "INSERT IGNORE INTO kamar (nama_kamar, kapasitas) VALUES ";
    foreach($kamar_list as $kamar) {
        $sql_kamar .= "('$kamar', 20),";
    }
    $sql_kamar = rtrim($sql_kamar, ',');
    
    // Insert jadwal kegiatan default
    $sql_kegiatan = "INSERT IGNORE INTO jadwal_kegiatan (nama_kegiatan, hari, jam_mulai, jam_selesai, deskripsi) VALUES 
        ('Bangun Pagi', 'Senin', '04:00', '04:30', 'Kegiatan bangun pagi dan persiapan'),
        ('Shalat Subuh', 'Senin', '04:30', '05:00', 'Shalat subuh berjamaah'),
        ('Ngaji Pagi', 'Senin', '05:00', '06:00', 'Kegiatan mengaji pagi'),
        ('Sarapan', 'Senin', '06:00', '06:30', 'Sarapan pagi'),
        ('Sekolah', 'Senin', '07:00', '15:00', 'Kegiatan sekolah formal'),
        ('Shalat Ashar', 'Senin', '15:30', '16:00', 'Shalat ashar berjamaah'),
        ('Ngaji Sore', 'Senin', '16:00', '17:30', 'Kegiatan mengaji sore'),
        ('Makan Malam', 'Senin', '18:00', '18:30', 'Makan malam'),
        ('Shalat Isya', 'Senin', '19:00', '19:30', 'Shalat isya berjamaah'),
        ('Belajar Malam', 'Senin', '19:30', '21:00', 'Kegiatan belajar malam'),
        ('Istirahat', 'Senin', '21:00', '04:00', 'Waktu istirahat')";
    
    try {
        $pdo->exec($sql_operator);
        $pdo->exec($sql_kamar);
        $pdo->exec($sql_kegiatan);
    } catch(PDOException $e) {
        // Ignore duplicate entry errors
    }
}

// Inisialisasi database dan tabel
createDatabase();
createTables();
?> 