<?php
session_start();
require_once '../config/database.php';

// Cek login
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'operator') {
    header('Location: ../login.php');
    exit();
}

$success = '';
$error = '';

// Proses approve/reject pendaftaran
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'approve':
                try {
                    $pendaftaran_id = $_POST['pendaftaran_id'];
                    
                    // Ambil data pendaftaran
                    $stmt = $pdo->prepare("SELECT * FROM pendaftaran WHERE id = ?");
                    $stmt->execute([$pendaftaran_id]);
                    $pendaftaran = $stmt->fetch();
                    
                    if ($pendaftaran) {
                        // Generate NIS
                        $tahun = date('Y');
                        $stmt = $pdo->query("SELECT COUNT(*) as total FROM santri WHERE YEAR(created_at) = $tahun");
                        $count = $stmt->fetch()['total'];
                        $nis = $tahun . str_pad($count + 1, 4, '0', STR_PAD_LEFT);
                        
                        // Insert ke tabel santri
                        $stmt = $pdo->prepare("INSERT INTO santri (nis, nisn, nik, nama_lengkap, tempat_lahir, tanggal_lahir, 
                                              jenis_kelamin, alamat, jenis_santri, jenjang_pendidikan, nama_wali, no_hp_wali) 
                                              VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
                        $stmt->execute([
                            $nis, $pendaftaran['nisn'], $pendaftaran['nik'], $pendaftaran['nama_lengkap'],
                            $pendaftaran['tempat_lahir'], $pendaftaran['tanggal_lahir'], $pendaftaran['jenis_kelamin'],
                            $pendaftaran['alamat'], $pendaftaran['jenis_santri'], $pendaftaran['jenjang_pendidikan'],
                            $pendaftaran['nama_wali'], $pendaftaran['no_hp_wali']
                        ]);
                        
                        // Update status pendaftaran
                        $stmt = $pdo->prepare("UPDATE pendaftaran SET status = 'diterima' WHERE id = ?");
                        $stmt->execute([$pendaftaran_id]);
                        
                        $success = 'Pendaftaran berhasil disetujui! NIS: ' . $nis;
                    }
                } catch(PDOException $e) {
                    $error = 'Error: ' . $e->getMessage();
                }
                break;
                
            case 'reject':
                try {
                    $pendaftaran_id = $_POST['pendaftaran_id'];
                    $alasan = $_POST['alasan'] ?? '';
                    
                    $stmt = $pdo->prepare("UPDATE pendaftaran SET status = 'ditolak' WHERE id = ?");
                    $stmt->execute([$pendaftaran_id]);
                    
                    $success = 'Pendaftaran berhasil ditolak!';
                } catch(PDOException $e) {
                    $error = 'Error: ' . $e->getMessage();
                }
                break;
        }
    }
}

// Ambil data pendaftaran
try {
    $status_filter = $_GET['status'] ?? '';
    $search = $_GET['search'] ?? '';
    
    $where_conditions = [];
    $params = [];
    
    if ($status_filter) {
        $where_conditions[] = "status = ?";
        $params[] = $status_filter;
    }
    
    if ($search) {
        $where_conditions[] = "(nama_lengkap LIKE ? OR nik LIKE ? OR nisn LIKE ?)";
        $params[] = "%$search%";
        $params[] = "%$search%";
        $params[] = "%$search%";
    }
    
    $where_clause = '';
    if (!empty($where_conditions)) {
        $where_clause = 'WHERE ' . implode(' AND ', $where_conditions);
    }
    
    $stmt = $pdo->prepare("
        SELECT * FROM pendaftaran 
        $where_clause 
        ORDER BY created_at DESC
    ");
    $stmt->execute($params);
    $pendaftaran_list = $stmt->fetchAll();
    
} catch(PDOException $e) {
    $error = 'Error: ' . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Review Pendaftaran - e-Pondok</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        .admin-container {
            display: flex;
            min-height: 100vh;
        }
        
        .sidebar {
            width: 250px;
            background: #2c5aa0;
            color: white;
            position: fixed;
            height: 100vh;
            overflow-y: auto;
        }
        
        .sidebar-header {
            padding: 20px;
            text-align: center;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }
        
        .sidebar-title {
            font-size: 1.2rem;
            font-weight: 700;
        }
        
        .sidebar-menu {
            padding: 20px 0;
        }
        
        .menu-item {
            display: block;
            padding: 15px 20px;
            color: white;
            text-decoration: none;
            transition: all 0.3s ease;
            border-left: 3px solid transparent;
        }
        
        .menu-item:hover,
        .menu-item.active {
            background: rgba(255, 255, 255, 0.1);
            border-left-color: #ff6b6b;
        }
        
        .menu-item i {
            margin-right: 10px;
            width: 20px;
        }
        
        .main-content {
            flex: 1;
            margin-left: 250px;
            background: #f8f9fa;
        }
        
        .top-bar {
            background: white;
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .page-title {
            font-size: 1.5rem;
            font-weight: 600;
            color: #2c5aa0;
        }
        
        .content-area {
            padding: 30px;
        }
        
        .filter-card {
            background: white;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            padding: 20px;
            margin-bottom: 30px;
        }
        
        .filter-form {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            align-items: end;
        }
        
        .form-group {
            margin-bottom: 0;
        }
        
        .form-label {
            display: block;
            margin-bottom: 5px;
            font-weight: 600;
            color: #333;
        }
        
        .form-control {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 0.9rem;
        }
        
        .form-control:focus {
            outline: none;
            border-color: #2c5aa0;
        }
        
        .btn-filter {
            background: #2c5aa0;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-weight: 600;
        }
        
        .pendaftaran-card {
            background: white;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            overflow: hidden;
        }
        
        .card-header {
            padding: 20px;
            background: #f8f9fa;
            border-bottom: 1px solid #e9ecef;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .card-title {
            font-size: 1.2rem;
            font-weight: 600;
            color: #2c5aa0;
        }
        
        .status-counts {
            display: flex;
            gap: 15px;
        }
        
        .status-count {
            padding: 5px 10px;
            border-radius: 15px;
            font-size: 0.8rem;
            font-weight: 600;
        }
        
        .status-pending { background: #fff3cd; color: #856404; }
        .status-diterima { background: #d4edda; color: #155724; }
        .status-ditolak { background: #f8d7da; color: #721c24; }
        
        .card-body {
            padding: 20px;
        }
        
        .pendaftaran-table {
            width: 100%;
            border-collapse: collapse;
        }
        
        .pendaftaran-table th,
        .pendaftaran-table td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #e9ecef;
        }
        
        .pendaftaran-table th {
            background: #f8f9fa;
            font-weight: 600;
            color: #333;
        }
        
        .pendaftaran-table tr:hover {
            background: #f8f9fa;
        }
        
        .status-badge {
            padding: 5px 10px;
            border-radius: 15px;
            font-size: 0.8rem;
            font-weight: 600;
        }
        
        .btn-action {
            padding: 5px 10px;
            border-radius: 3px;
            text-decoration: none;
            font-size: 0.8rem;
            margin-right: 5px;
            border: none;
            cursor: pointer;
        }
        
        .btn-approve {
            background: #28a745;
            color: white;
        }
        
        .btn-reject {
            background: #dc3545;
            color: white;
        }
        
        .btn-view {
            background: #17a2b8;
            color: white;
        }
        
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
        }
        
        .modal-content {
            background-color: white;
            margin: 5% auto;
            padding: 0;
            border-radius: 10px;
            width: 90%;
            max-width: 600px;
            max-height: 80vh;
            overflow-y: auto;
        }
        
        .modal-header {
            padding: 20px;
            background: #f8f9fa;
            border-bottom: 1px solid #e9ecef;
        }
        
        .modal-title {
            font-size: 1.2rem;
            font-weight: 600;
            color: #2c5aa0;
        }
        
        .modal-body {
            padding: 20px;
        }
        
        .modal-footer {
            padding: 20px;
            background: #f8f9fa;
            border-top: 1px solid #e9ecef;
            text-align: right;
        }
        
        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-weight: 600;
            margin-left: 10px;
        }
        
        .btn-primary {
            background: #2c5aa0;
            color: white;
        }
        
        .btn-secondary {
            background: #6c757d;
            color: white;
        }
        
        .alert {
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
        }
        
        .alert-success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        
        .alert-danger {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        
        .detail-row {
            display: flex;
            justify-content: space-between;
            margin-bottom: 10px;
        }
        
        .detail-label {
            font-weight: 600;
            color: #333;
        }
        
        .detail-value {
            color: #666;
        }
        
        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
                transition: transform 0.3s ease;
            }
            
            .sidebar.active {
                transform: translateX(0);
            }
            
            .main-content {
                margin-left: 0;
            }
            
            .filter-form {
                grid-template-columns: 1fr;
            }
            
            .pendaftaran-table {
                font-size: 0.8rem;
            }
            
            .pendaftaran-table th,
            .pendaftaran-table td {
                padding: 8px;
            }
            
            .status-counts {
                flex-direction: column;
                gap: 5px;
            }
        }
    </style>
</head>
<body>
    <div class="admin-container">
        <!-- Sidebar -->
        <div class="sidebar" id="sidebar">
            <div class="sidebar-header">
                <h2 class="sidebar-title">e-Pondok</h2>
                <p>Operator Panel</p>
            </div>
            <div class="sidebar-menu">
                <a href="dashboard.php" class="menu-item">
                    <i class="fas fa-tachometer-alt"></i> Dashboard
                </a>
                <a href="santri.php" class="menu-item">
                    <i class="fas fa-users"></i> Data Santri
                </a>
                <a href="guru.php" class="menu-item">
                    <i class="fas fa-chalkboard-teacher"></i> Data Guru
                </a>
                <a href="kelas.php" class="menu-item">
                    <i class="fas fa-school"></i> Kelas
                </a>
                <a href="mapel.php" class="menu-item">
                    <i class="fas fa-book"></i> Mata Pelajaran
                </a>
                <a href="jadwal.php" class="menu-item">
                    <i class="fas fa-calendar-alt"></i> Jadwal
                </a>
                <a href="kamar.php" class="menu-item">
                    <i class="fas fa-bed"></i> Kamar
                </a>
                <a href="pendaftaran.php" class="menu-item active">
                    <i class="fas fa-user-plus"></i> Pendaftaran
                </a>
                <a href="rapot.php" class="menu-item">
                    <i class="fas fa-file-alt"></i> e-Rapot
                </a>
                <a href="monitoring.php" class="menu-item">
                    <i class="fas fa-chart-line"></i> Monitoring
                </a>
            </div>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <div class="top-bar">
                <div class="page-title">Review Pendaftaran Santri</div>
            </div>

            <div class="content-area">
                <?php if ($success): ?>
                    <div class="alert alert-success">
                        <i class="fas fa-check-circle"></i> <?php echo $success; ?>
                    </div>
                <?php endif; ?>
                
                <?php if ($error): ?>
                    <div class="alert alert-danger">
                        <i class="fas fa-exclamation-triangle"></i> <?php echo $error; ?>
                    </div>
                <?php endif; ?>

                <!-- Filter Card -->
                <div class="filter-card">
                    <form method="GET" class="filter-form">
                        <div class="form-group">
                            <label class="form-label">Cari</label>
                            <input type="text" name="search" class="form-control" placeholder="Nama, NIK, atau NISN..." value="<?php echo htmlspecialchars($search); ?>">
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label">Status</label>
                            <select name="status" class="form-control">
                                <option value="">Semua Status</option>
                                <option value="pending" <?php echo ($status_filter == 'pending') ? 'selected' : ''; ?>>Pending</option>
                                <option value="diterima" <?php echo ($status_filter == 'diterima') ? 'selected' : ''; ?>>Diterima</option>
                                <option value="ditolak" <?php echo ($status_filter == 'ditolak') ? 'selected' : ''; ?>>Ditolak</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <button type="submit" class="btn-filter">
                                <i class="fas fa-search"></i> Filter
                            </button>
                        </div>
                    </form>
                </div>

                <!-- Pendaftaran Card -->
                <div class="pendaftaran-card">
                    <div class="card-header">
                        <h3 class="card-title">Daftar Pendaftaran</h3>
                        <div class="status-counts">
                            <span class="status-count status-pending">Pending: <?php echo count(array_filter($pendaftaran_list, function($p) { return $p['status'] == 'pending'; })); ?></span>
                            <span class="status-count status-diterima">Diterima: <?php echo count(array_filter($pendaftaran_list, function($p) { return $p['status'] == 'diterima'; })); ?></span>
                            <span class="status-count status-ditolak">Ditolak: <?php echo count(array_filter($pendaftaran_list, function($p) { return $p['status'] == 'ditolak'; })); ?></span>
                        </div>
                    </div>
                    
                    <div class="card-body">
                        <div class="table-container">
                            <table class="pendaftaran-table">
                                <thead>
                                    <tr>
                                        <th>Tanggal</th>
                                        <th>Nama Lengkap</th>
                                        <th>NIK</th>
                                        <th>Jenis Santri</th>
                                        <th>Jenjang</th>
                                        <th>Status</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($pendaftaran_list as $pendaftaran): ?>
                                    <tr>
                                        <td><?php echo date('d/m/Y', strtotime($pendaftaran['created_at'])); ?></td>
                                        <td><?php echo htmlspecialchars($pendaftaran['nama_lengkap']); ?></td>
                                        <td><?php echo htmlspecialchars($pendaftaran['nik']); ?></td>
                                        <td><?php echo htmlspecialchars($pendaftaran['jenis_santri']); ?></td>
                                        <td><?php echo htmlspecialchars($pendaftaran['jenjang_pendidikan']); ?></td>
                                        <td>
                                            <span class="status-badge status-<?php echo $pendaftaran['status']; ?>">
                                                <?php echo ucfirst($pendaftaran['status']); ?>
                                            </span>
                                        </td>
                                        <td>
                                            <button class="btn-action btn-view" onclick="viewDetail(<?php echo $pendaftaran['id']; ?>)">
                                                <i class="fas fa-eye"></i> Detail
                                            </button>
                                            <?php if ($pendaftaran['status'] == 'pending'): ?>
                                            <button class="btn-action btn-approve" onclick="approvePendaftaran(<?php echo $pendaftaran['id']; ?>)">
                                                <i class="fas fa-check"></i> Terima
                                            </button>
                                            <button class="btn-action btn-reject" onclick="rejectPendaftaran(<?php echo $pendaftaran['id']; ?>)">
                                                <i class="fas fa-times"></i> Tolak
                                            </button>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal Detail Pendaftaran -->
    <div id="detailModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title">Detail Pendaftaran</h3>
            </div>
            <div class="modal-body" id="detailContent">
                <!-- Content will be loaded here -->
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" onclick="closeModal()">Tutup</button>
            </div>
        </div>
    </div>

    <!-- Modal Reject Pendaftaran -->
    <div id="rejectModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title">Tolak Pendaftaran</h3>
            </div>
            <form method="POST">
                <input type="hidden" name="action" value="reject">
                <input type="hidden" name="pendaftaran_id" id="rejectPendaftaranId">
                <div class="modal-body">
                    <div class="form-group">
                        <label class="form-label">Alasan Penolakan (Opsional)</label>
                        <textarea name="alasan" class="form-control" rows="3" placeholder="Masukkan alasan penolakan..."></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" onclick="closeRejectModal()">Batal</button>
                    <button type="submit" class="btn btn-primary" style="background: #dc3545;">Tolak</button>
                </div>
            </form>
        </div>
    </div>

    <script src="../assets/js/script.js"></script>
    <script>
        // View detail pendaftaran
        function viewDetail(id) {
            // Implement AJAX call to get detail
            document.getElementById('detailModal').style.display = 'block';
            document.getElementById('detailContent').innerHTML = '<p>Loading...</p>';
            
            // Simulate loading detail
            setTimeout(() => {
                document.getElementById('detailContent').innerHTML = `
                    <div class="detail-row">
                        <span class="detail-label">ID Pendaftaran:</span>
                        <span class="detail-value">${id}</span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Nama Lengkap:</span>
                        <span class="detail-value">John Doe</span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">NIK:</span>
                        <span class="detail-value">1234567890123456</span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Jenis Santri:</span>
                        <span class="detail-value">Pondok Kitab</span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Jenjang:</span>
                        <span class="detail-value">SMP</span>
                    </div>
                `;
            }, 500);
        }

        // Approve pendaftaran
        function approvePendaftaran(id) {
            if (confirm('Apakah Anda yakin ingin menerima pendaftaran ini?')) {
                const form = document.createElement('form');
                form.method = 'POST';
                form.innerHTML = `
                    <input type="hidden" name="action" value="approve">
                    <input type="hidden" name="pendaftaran_id" value="${id}">
                `;
                document.body.appendChild(form);
                form.submit();
            }
        }

        // Reject pendaftaran
        function rejectPendaftaran(id) {
            document.getElementById('rejectPendaftaranId').value = id;
            document.getElementById('rejectModal').style.display = 'block';
        }

        // Close modals
        function closeModal() {
            document.getElementById('detailModal').style.display = 'none';
        }

        function closeRejectModal() {
            document.getElementById('rejectModal').style.display = 'none';
        }

        // Close modal when clicking outside
        window.onclick = function(event) {
            const detailModal = document.getElementById('detailModal');
            const rejectModal = document.getElementById('rejectModal');
            
            if (event.target == detailModal) {
                detailModal.style.display = 'none';
            }
            if (event.target == rejectModal) {
                rejectModal.style.display = 'none';
            }
        }
    </script>
</body>
</html> 