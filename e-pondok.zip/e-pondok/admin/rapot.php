<?php
session_start();
require_once '../config/database.php';

// Cek login
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'operator') {
    header('Location: ../login.php');
    exit();
}

$success = '';
$error = '';

// Ambil data untuk filter
try {
    $selected_kelas = $_GET['kelas_id'] ?? '';
    $selected_semester = $_GET['semester'] ?? '1';
    $selected_santri = $_GET['santri_id'] ?? '';
    
    // Ambil data kelas
    $stmt = $pdo->query("SELECT * FROM kelas ORDER BY nama_kelas");
    $kelas_list = $stmt->fetchAll();
    
    // Ambil data santri berdasarkan kelas
    $santri_list = [];
    if ($selected_kelas) {
        $stmt = $pdo->prepare("SELECT * FROM santri WHERE kelas_id = ? AND status_santri = 'aktif' ORDER BY nama_lengkap");
        $stmt->execute([$selected_kelas]);
        $santri_list = $stmt->fetchAll();
    }
    
    // Ambil data nilai jika ada santri yang dipilih
    $nilai_data = [];
    if ($selected_santri) {
        $stmt = $pdo->prepare("
            SELECT n.*, mp.nama_mapel, g.nama_lengkap as nama_guru
            FROM nilai n
            JOIN mata_pelajaran mp ON n.mata_pelajaran_id = mp.id
            JOIN guru g ON n.guru_id = g.id
            WHERE n.santri_id = ? AND n.semester = ?
            ORDER BY mp.nama_mapel
        ");
        $stmt->execute([$selected_santri, $selected_semester]);
        $nilai_data = $stmt->fetchAll();
        
        // Ambil data santri
        $stmt = $pdo->prepare("SELECT * FROM santri WHERE id = ?");
        $stmt->execute([$selected_santri]);
        $santri_info = $stmt->fetch();
    }
    
} catch(PDOException $e) {
    $error = 'Error: ' . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>e-Rapot - e-Pondok</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        .admin-container {
            display: flex;
            min-height: 100vh;
        }
        
        .sidebar {
            width: 250px;
            background: #2c5aa0;
            color: white;
            position: fixed;
            height: 100vh;
            overflow-y: auto;
        }
        
        .sidebar-header {
            padding: 20px;
            text-align: center;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }
        
        .sidebar-title {
            font-size: 1.2rem;
            font-weight: 700;
        }
        
        .sidebar-menu {
            padding: 20px 0;
        }
        
        .menu-item {
            display: block;
            padding: 15px 20px;
            color: white;
            text-decoration: none;
            transition: all 0.3s ease;
            border-left: 3px solid transparent;
        }
        
        .menu-item:hover,
        .menu-item.active {
            background: rgba(255, 255, 255, 0.1);
            border-left-color: #ff6b6b;
        }
        
        .menu-item i {
            margin-right: 10px;
            width: 20px;
        }
        
        .main-content {
            flex: 1;
            margin-left: 250px;
            background: #f8f9fa;
        }
        
        .top-bar {
            background: white;
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .page-title {
            font-size: 1.5rem;
            font-weight: 600;
            color: #2c5aa0;
        }
        
        .content-area {
            padding: 30px;
        }
        
        .filter-card {
            background: white;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            padding: 20px;
            margin-bottom: 30px;
        }
        
        .filter-title {
            font-size: 1.1rem;
            font-weight: 600;
            color: #333;
            margin-bottom: 15px;
        }
        
        .filter-form {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            align-items: end;
        }
        
        .form-group {
            margin-bottom: 0;
        }
        
        .form-label {
            display: block;
            margin-bottom: 5px;
            font-weight: 600;
            color: #333;
        }
        
        .form-control {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 0.9rem;
        }
        
        .form-control:focus {
            outline: none;
            border-color: #2c5aa0;
        }
        
        .btn-filter {
            background: #2c5aa0;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-weight: 600;
        }
        
        .rapot-card {
            background: white;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            overflow: hidden;
        }
        
        .card-header {
            padding: 20px;
            background: #f8f9fa;
            border-bottom: 1px solid #e9ecef;
        }
        
        .card-title {
            font-size: 1.2rem;
            font-weight: 600;
            color: #2c5aa0;
        }
        
        .card-body {
            padding: 20px;
        }
        
        .santri-info {
            background: #e3f2fd;
            border: 1px solid #bbdefb;
            border-radius: 5px;
            padding: 20px;
            margin-bottom: 20px;
        }
        
        .santri-info h3 {
            margin: 0 0 15px 0;
            color: #1976d2;
        }
        
        .info-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
        }
        
        .info-item {
            display: flex;
            justify-content: space-between;
        }
        
        .info-label {
            font-weight: 600;
            color: #333;
        }
        
        .info-value {
            color: #666;
        }
        
        .nilai-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        
        .nilai-table th,
        .nilai-table td {
            padding: 12px;
            text-align: center;
            border-bottom: 1px solid #e9ecef;
        }
        
        .nilai-table th {
            background: #f8f9fa;
            font-weight: 600;
            color: #333;
        }
        
        .nilai-table th:first-child,
        .nilai-table td:first-child {
            text-align: left;
        }
        
        .nilai-cell {
            font-weight: 600;
        }
        
        .nilai-a { color: #28a745; }
        .nilai-b { color: #ffc107; }
        .nilai-c { color: #fd7e14; }
        .nilai-d { color: #dc3545; }
        
        .btn-print {
            background: #28a745;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-weight: 600;
            margin-top: 20px;
        }
        
        .btn-print:hover {
            background: #218838;
        }
        
        .alert {
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
        }
        
        .alert-danger {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        
        .no-data {
            text-align: center;
            padding: 40px;
            color: #666;
        }
        
        .no-data i {
            font-size: 3rem;
            margin-bottom: 15px;
            color: #ddd;
        }
        
        .summary-card {
            background: #f8f9fa;
            border-radius: 5px;
            padding: 15px;
            margin-top: 20px;
        }
        
        .summary-title {
            font-weight: 600;
            color: #333;
            margin-bottom: 10px;
        }
        
        .summary-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 15px;
        }
        
        .summary-item {
            text-align: center;
            padding: 10px;
            background: white;
            border-radius: 5px;
            border: 1px solid #e9ecef;
        }
        
        .summary-number {
            font-size: 1.5rem;
            font-weight: 700;
            color: #2c5aa0;
        }
        
        .summary-label {
            font-size: 0.9rem;
            color: #666;
        }
        
        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
                transition: transform 0.3s ease;
            }
            
            .sidebar.active {
                transform: translateX(0);
            }
            
            .main-content {
                margin-left: 0;
            }
            
            .filter-form {
                grid-template-columns: 1fr;
            }
            
            .nilai-table {
                font-size: 0.8rem;
            }
            
            .nilai-table th,
            .nilai-table td {
                padding: 8px;
            }
            
            .info-grid {
                grid-template-columns: 1fr;
            }
        }
        
        @media print {
            .sidebar, .top-bar, .filter-card, .btn-print {
                display: none !important;
            }
            
            .main-content {
                margin-left: 0 !important;
            }
            
            .rapot-card {
                box-shadow: none !important;
            }
        }
    </style>
</head>
<body>
    <div class="admin-container">
        <!-- Sidebar -->
        <div class="sidebar" id="sidebar">
            <div class="sidebar-header">
                <h2 class="sidebar-title">e-Pondok</h2>
                <p>Operator Panel</p>
            </div>
            <div class="sidebar-menu">
                <a href="dashboard.php" class="menu-item">
                    <i class="fas fa-tachometer-alt"></i> Dashboard
                </a>
                <a href="santri.php" class="menu-item">
                    <i class="fas fa-users"></i> Data Santri
                </a>
                <a href="guru.php" class="menu-item">
                    <i class="fas fa-chalkboard-teacher"></i> Data Guru
                </a>
                <a href="kelas.php" class="menu-item">
                    <i class="fas fa-school"></i> Kelas
                </a>
                <a href="mapel.php" class="menu-item">
                    <i class="fas fa-book"></i> Mata Pelajaran
                </a>
                <a href="jadwal.php" class="menu-item">
                    <i class="fas fa-calendar-alt"></i> Jadwal
                </a>
                <a href="kamar.php" class="menu-item">
                    <i class="fas fa-bed"></i> Kamar
                </a>
                <a href="pendaftaran.php" class="menu-item">
                    <i class="fas fa-user-plus"></i> Pendaftaran
                </a>
                <a href="rapot.php" class="menu-item active">
                    <i class="fas fa-file-alt"></i> e-Rapot
                </a>
                <a href="monitoring.php" class="menu-item">
                    <i class="fas fa-chart-line"></i> Monitoring
                </a>
            </div>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <div class="top-bar">
                <div class="page-title">e-Rapot Santri</div>
            </div>

            <div class="content-area">
                <?php if ($error): ?>
                    <div class="alert alert-danger">
                        <i class="fas fa-exclamation-triangle"></i> <?php echo $error; ?>
                    </div>
                <?php endif; ?>

                <!-- Filter Card -->
                <div class="filter-card">
                    <h3 class="filter-title">Pilih Santri dan Semester</h3>
                    <form method="GET" class="filter-form">
                        <div class="form-group">
                            <label class="form-label">Kelas</label>
                            <select name="kelas_id" class="form-control" required onchange="this.form.submit()">
                                <option value="">Pilih Kelas</option>
                                <?php foreach ($kelas_list as $kelas): ?>
                                <option value="<?php echo $kelas['id']; ?>" 
                                        <?php echo ($selected_kelas == $kelas['id']) ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($kelas['nama_kelas']); ?>
                                </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <?php if ($selected_kelas): ?>
                        <div class="form-group">
                            <label class="form-label">Santri</label>
                            <select name="santri_id" class="form-control" required onchange="this.form.submit()">
                                <option value="">Pilih Santri</option>
                                <?php foreach ($santri_list as $santri): ?>
                                <option value="<?php echo $santri['id']; ?>" 
                                        <?php echo ($selected_santri == $santri['id']) ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($santri['nama_lengkap']); ?> (<?php echo htmlspecialchars($santri['nis']); ?>)
                                </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <?php endif; ?>
                        
                        <?php if ($selected_santri): ?>
                        <div class="form-group">
                            <label class="form-label">Semester</label>
                            <select name="semester" class="form-control" required onchange="this.form.submit()">
                                <option value="1" <?php echo ($selected_semester == '1') ? 'selected' : ''; ?>>Semester 1</option>
                                <option value="2" <?php echo ($selected_semester == '2') ? 'selected' : ''; ?>>Semester 2</option>
                            </select>
                        </div>
                        <?php endif; ?>
                    </form>
                </div>

                <!-- Rapot Card -->
                <?php if ($selected_santri && !empty($nilai_data)): ?>
                <div class="rapot-card">
                    <div class="card-header">
                        <h3 class="card-title">Rapot Semester <?php echo $selected_semester; ?></h3>
                        <button class="btn-print" onclick="window.print()">
                            <i class="fas fa-print"></i> Cetak Rapot
                        </button>
                    </div>
                    
                    <div class="card-body">
                        <!-- Info Santri -->
                        <div class="santri-info">
                            <h3>Data Santri</h3>
                            <div class="info-grid">
                                <div class="info-item">
                                    <span class="info-label">Nama Lengkap:</span>
                                    <span class="info-value"><?php echo htmlspecialchars($santri_info['nama_lengkap']); ?></span>
                                </div>
                                <div class="info-item">
                                    <span class="info-label">NIS:</span>
                                    <span class="info-value"><?php echo htmlspecialchars($santri_info['nis']); ?></span>
                                </div>
                                <div class="info-item">
                                    <span class="info-label">NISN:</span>
                                    <span class="info-value"><?php echo htmlspecialchars($santri_info['nisn'] ?? '-'); ?></span>
                                </div>
                                <div class="info-item">
                                    <span class="info-label">Jenis Santri:</span>
                                    <span class="info-value"><?php echo htmlspecialchars($santri_info['jenis_santri']); ?></span>
                                </div>
                                <div class="info-item">
                                    <span class="info-label">Jenjang:</span>
                                    <span class="info-value"><?php echo htmlspecialchars($santri_info['jenjang_pendidikan']); ?></span>
                                </div>
                                <div class="info-item">
                                    <span class="info-label">Kamar:</span>
                                    <span class="info-value"><?php echo htmlspecialchars($santri_info['kamar'] ?? '-'); ?></span>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Tabel Nilai -->
                        <table class="nilai-table">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Mata Pelajaran</th>
                                    <th>Guru</th>
                                    <th>Tugas 1</th>
                                    <th>Tugas 2</th>
                                    <th>UTS</th>
                                    <th>UAS</th>
                                    <th>Nilai Akhir</th>
                                    <th>Grade</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                $total_nilai = 0;
                                $jumlah_mapel = count($nilai_data);
                                foreach ($nilai_data as $index => $nilai): 
                                    $total_nilai += $nilai['nilai_akhir'];
                                    $grade = getGrade($nilai['nilai_akhir']);
                                ?>
                                <tr>
                                    <td><?php echo $index + 1; ?></td>
                                    <td><?php echo htmlspecialchars($nilai['nama_mapel']); ?></td>
                                    <td><?php echo htmlspecialchars($nilai['nama_guru']); ?></td>
                                    <td class="nilai-cell"><?php echo $nilai['tugas_1'] ? number_format($nilai['tugas_1'], 1) : '-'; ?></td>
                                    <td class="nilai-cell"><?php echo $nilai['tugas_2'] ? number_format($nilai['tugas_2'], 1) : '-'; ?></td>
                                    <td class="nilai-cell"><?php echo $nilai['uts'] ? number_format($nilai['uts'], 1) : '-'; ?></td>
                                    <td class="nilai-cell"><?php echo $nilai['uas'] ? number_format($nilai['uas'], 1) : '-'; ?></td>
                                    <td class="nilai-cell"><?php echo number_format($nilai['nilai_akhir'], 2); ?></td>
                                    <td class="nilai-cell nilai-<?php echo strtolower($grade); ?>"><?php echo $grade; ?></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                        
                        <!-- Summary -->
                        <div class="summary-card">
                            <h4 class="summary-title">Ringkasan Nilai</h4>
                            <div class="summary-grid">
                                <div class="summary-item">
                                    <div class="summary-number"><?php echo $jumlah_mapel; ?></div>
                                    <div class="summary-label">Mata Pelajaran</div>
                                </div>
                                <div class="summary-item">
                                    <div class="summary-number"><?php echo number_format($total_nilai / $jumlah_mapel, 2); ?></div>
                                    <div class="summary-label">Rata-rata</div>
                                </div>
                                <div class="summary-item">
                                    <div class="summary-number"><?php echo getGrade($total_nilai / $jumlah_mapel); ?></div>
                                    <div class="summary-label">Grade Rata-rata</div>
                                </div>
                                <div class="summary-item">
                                    <div class="summary-number"><?php echo $selected_semester; ?></div>
                                    <div class="summary-label">Semester</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <?php elseif ($selected_santri): ?>
                <div class="rapot-card">
                    <div class="no-data">
                        <i class="fas fa-file-alt"></i>
                        <h3>Belum ada nilai</h3>
                        <p>Santri ini belum memiliki nilai untuk semester <?php echo $selected_semester; ?>.</p>
                    </div>
                </div>
                
                <?php else: ?>
                <div class="rapot-card">
                    <div class="no-data">
                        <i class="fas fa-file-alt"></i>
                        <h3>Pilih Santri</h3>
                        <p>Silakan pilih kelas, santri, dan semester di atas untuk melihat rapot.</p>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script src="../assets/js/script.js"></script>
</body>
</html>

<?php
// Function to get grade
function getGrade($nilai) {
    if ($nilai >= 90) return 'A';
    elseif ($nilai >= 80) return 'B';
    elseif ($nilai >= 70) return 'C';
    elseif ($nilai >= 60) return 'D';
    else return 'E';
}
?> 