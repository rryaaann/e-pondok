<?php
session_start();
require_once '../config/database.php';

// Cek login
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'operator') {
    header('Location: ../login.php');
    exit();
}

$success = '';
$error = '';

// Ambil data monitoring
try {
    // Statistik umum
    $stmt = $pdo->query("SELECT COUNT(*) as total_santri FROM santri WHERE status_santri = 'aktif'");
    $total_santri = $stmt->fetch()['total_santri'];
    
    $stmt = $pdo->query("SELECT COUNT(*) as total_guru FROM guru WHERE status = 'aktif'");
    $total_guru = $stmt->fetch()['total_guru'];
    
    $stmt = $pdo->query("SELECT COUNT(*) as total_kelas FROM kelas");
    $total_kelas = $stmt->fetch()['total_kelas'];
    
    $stmt = $pdo->query("SELECT COUNT(*) as total_mapel FROM mata_pelajaran");
    $total_mapel = $stmt->fetch()['total_mapel'];
    
    // Absensi hari ini
    $stmt = $pdo->query("
        SELECT 
            COUNT(*) as total_absen,
            SUM(CASE WHEN status = 'hadir' THEN 1 ELSE 0 END) as hadir,
            SUM(CASE WHEN status = 'sakit' THEN 1 ELSE 0 END) as sakit,
            SUM(CASE WHEN status = 'izin' THEN 1 ELSE 0 END) as izin,
            SUM(CASE WHEN status = 'alpha' THEN 1 ELSE 0 END) as alpha
        FROM absensi 
        WHERE tanggal = CURDATE()
    ");
    $absensi_hari_ini = $stmt->fetch();
    
    // Santri per kamar
    $stmt = $pdo->query("
        SELECT kamar, COUNT(*) as jumlah 
        FROM santri 
        WHERE status_santri = 'aktif' AND kamar IS NOT NULL
        GROUP BY kamar 
        ORDER BY jumlah DESC
    ");
    $santri_per_kamar = $stmt->fetchAll();
    
    // Santri per jenjang
    $stmt = $pdo->query("
        SELECT jenjang_pendidikan, COUNT(*) as jumlah 
        FROM santri 
        WHERE status_santri = 'aktif'
        GROUP BY jenjang_pendidikan
    ");
    $santri_per_jenjang = $stmt->fetchAll();
    
    // Santri per jenis
    $stmt = $pdo->query("
        SELECT jenis_santri, COUNT(*) as jumlah 
        FROM santri 
        WHERE status_santri = 'aktif'
        GROUP BY jenis_santri
    ");
    $santri_per_jenis = $stmt->fetchAll();
    
    // Absensi per kelas hari ini
    $stmt = $pdo->query("
        SELECT 
            k.nama_kelas,
            COUNT(DISTINCT a.santri_id) as total_santri,
            SUM(CASE WHEN a.status = 'hadir' THEN 1 ELSE 0 END) as hadir,
            SUM(CASE WHEN a.status = 'sakit' THEN 1 ELSE 0 END) as sakit,
            SUM(CASE WHEN a.status = 'izin' THEN 1 ELSE 0 END) as izin,
            SUM(CASE WHEN a.status = 'alpha' THEN 1 ELSE 0 END) as alpha
        FROM absensi a
        JOIN santri s ON a.santri_id = s.id
        JOIN kelas k ON s.kelas_id = k.id
        WHERE a.tanggal = CURDATE()
        GROUP BY k.id, k.nama_kelas
        ORDER BY k.nama_kelas
    ");
    $absensi_per_kelas = $stmt->fetchAll();
    
    // Guru yang mengajar hari ini
    $hari_ini = date('l');
    $hari_indonesia = [
        'Monday' => 'Senin',
        'Tuesday' => 'Selasa', 
        'Wednesday' => 'Rabu',
        'Thursday' => 'Kamis',
        'Friday' => 'Jumat',
        'Saturday' => 'Sabtu',
        'Sunday' => 'Minggu'
    ];
    $hari = $hari_indonesia[$hari_ini];
    
    $stmt = $pdo->prepare("
        SELECT DISTINCT g.nama_lengkap, mp.nama_mapel, k.nama_kelas, jp.jam_mulai, jp.jam_selesai
        FROM jadwal_pelajaran jp
        JOIN guru g ON jp.guru_id = g.id
        JOIN mata_pelajaran mp ON jp.mata_pelajaran_id = mp.id
        JOIN kelas k ON jp.kelas_id = k.id
        WHERE jp.hari = ?
        ORDER BY jp.jam_mulai
    ");
    $stmt->execute([$hari]);
    $jadwal_hari_ini = $stmt->fetchAll();
    
} catch(PDOException $e) {
    $error = 'Error: ' . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Monitoring - e-Pondok</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        .admin-container {
            display: flex;
            min-height: 100vh;
        }
        
        .sidebar {
            width: 250px;
            background: #2c5aa0;
            color: white;
            position: fixed;
            height: 100vh;
            overflow-y: auto;
        }
        
        .sidebar-header {
            padding: 20px;
            text-align: center;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }
        
        .sidebar-title {
            font-size: 1.2rem;
            font-weight: 700;
        }
        
        .sidebar-menu {
            padding: 20px 0;
        }
        
        .menu-item {
            display: block;
            padding: 15px 20px;
            color: white;
            text-decoration: none;
            transition: all 0.3s ease;
            border-left: 3px solid transparent;
        }
        
        .menu-item:hover,
        .menu-item.active {
            background: rgba(255, 255, 255, 0.1);
            border-left-color: #ff6b6b;
        }
        
        .menu-item i {
            margin-right: 10px;
            width: 20px;
        }
        
        .main-content {
            flex: 1;
            margin-left: 250px;
            background: #f8f9fa;
        }
        
        .top-bar {
            background: white;
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .page-title {
            font-size: 1.5rem;
            font-weight: 600;
            color: #2c5aa0;
        }
        
        .content-area {
            padding: 30px;
        }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .stat-card {
            background: white;
            padding: 25px;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease;
        }
        
        .stat-card:hover {
            transform: translateY(-5px);
        }
        
        .stat-icon {
            width: 60px;
            height: 60px;
            border-radius: 15px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            color: white;
            margin-bottom: 15px;
        }
        
        .stat-icon.blue { background: #2c5aa0; }
        .stat-icon.green { background: #28a745; }
        .stat-icon.orange { background: #ffc107; }
        .stat-icon.red { background: #dc3545; }
        .stat-icon.purple { background: #6f42c1; }
        
        .stat-number {
            font-size: 2rem;
            font-weight: 700;
            color: #333;
            margin-bottom: 5px;
        }
        
        .stat-label {
            color: #666;
            font-size: 0.9rem;
        }
        
        .monitoring-grid {
            display: grid;
            grid-template-columns: 2fr 1fr;
            gap: 30px;
        }
        
        .monitoring-card {
            background: white;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            overflow: hidden;
        }
        
        .card-header {
            padding: 20px;
            background: #f8f9fa;
            border-bottom: 1px solid #e9ecef;
        }
        
        .card-title {
            font-size: 1.2rem;
            font-weight: 600;
            color: #2c5aa0;
        }
        
        .card-body {
            padding: 20px;
        }
        
        .monitoring-table {
            width: 100%;
            border-collapse: collapse;
        }
        
        .monitoring-table th,
        .monitoring-table td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #e9ecef;
        }
        
        .monitoring-table th {
            background: #f8f9fa;
            font-weight: 600;
            color: #333;
        }
        
        .monitoring-table tr:hover {
            background: #f8f9fa;
        }
        
        .progress-bar {
            width: 100%;
            height: 8px;
            background: #e9ecef;
            border-radius: 4px;
            overflow: hidden;
            margin-top: 5px;
        }
        
        .progress-fill {
            height: 100%;
            background: #28a745;
            transition: width 0.3s ease;
        }
        
        .progress-fill.warning {
            background: #ffc107;
        }
        
        .progress-fill.danger {
            background: #dc3545;
        }
        
        .chart-container {
            margin-top: 20px;
        }
        
        .chart-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 0;
            border-bottom: 1px solid #e9ecef;
        }
        
        .chart-item:last-child {
            border-bottom: none;
        }
        
        .chart-label {
            font-weight: 600;
            color: #333;
        }
        
        .chart-value {
            color: #666;
        }
        
        .alert {
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
        }
        
        .alert-danger {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        
        .today-info {
            background: #e3f2fd;
            border: 1px solid #bbdefb;
            border-radius: 5px;
            padding: 15px;
            margin-bottom: 20px;
        }
        
        .today-info h4 {
            margin: 0 0 10px 0;
            color: #1976d2;
        }
        
        .today-info p {
            margin: 0;
            color: #424242;
        }
        
        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
                transition: transform 0.3s ease;
            }
            
            .sidebar.active {
                transform: translateX(0);
            }
            
            .main-content {
                margin-left: 0;
            }
            
            .monitoring-grid {
                grid-template-columns: 1fr;
            }
            
            .stats-grid {
                grid-template-columns: repeat(2, 1fr);
            }
            
            .monitoring-table {
                font-size: 0.8rem;
            }
            
            .monitoring-table th,
            .monitoring-table td {
                padding: 8px;
            }
        }
    </style>
</head>
<body>
    <div class="admin-container">
        <!-- Sidebar -->
        <div class="sidebar" id="sidebar">
            <div class="sidebar-header">
                <h2 class="sidebar-title">e-Pondok</h2>
                <p>Operator Panel</p>
            </div>
            <div class="sidebar-menu">
                <a href="dashboard.php" class="menu-item">
                    <i class="fas fa-tachometer-alt"></i> Dashboard
                </a>
                <a href="santri.php" class="menu-item">
                    <i class="fas fa-users"></i> Data Santri
                </a>
                <a href="guru.php" class="menu-item">
                    <i class="fas fa-chalkboard-teacher"></i> Data Guru
                </a>
                <a href="kelas.php" class="menu-item">
                    <i class="fas fa-school"></i> Kelas
                </a>
                <a href="mapel.php" class="menu-item">
                    <i class="fas fa-book"></i> Mata Pelajaran
                </a>
                <a href="jadwal.php" class="menu-item">
                    <i class="fas fa-calendar-alt"></i> Jadwal
                </a>
                <a href="kamar.php" class="menu-item">
                    <i class="fas fa-bed"></i> Kamar
                </a>
                <a href="pendaftaran.php" class="menu-item">
                    <i class="fas fa-user-plus"></i> Pendaftaran
                </a>
                <a href="rapot.php" class="menu-item">
                    <i class="fas fa-file-alt"></i> e-Rapot
                </a>
                <a href="monitoring.php" class="menu-item active">
                    <i class="fas fa-chart-line"></i> Monitoring
                </a>
            </div>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <div class="top-bar">
                <div class="page-title">Monitoring Sistem</div>
            </div>

            <div class="content-area">
                <?php if ($error): ?>
                    <div class="alert alert-danger">
                        <i class="fas fa-exclamation-triangle"></i> <?php echo $error; ?>
                    </div>
                <?php endif; ?>

                <!-- Today Info -->
                <div class="today-info">
                    <h4><i class="fas fa-calendar-day"></i> Informasi Hari Ini</h4>
                    <p><strong>Tanggal:</strong> <?php echo date('d F Y'); ?> (<?php echo $hari; ?>)</p>
                    <p><strong>Total Absensi:</strong> <?php echo $absensi_hari_ini['total_absen']; ?> santri</p>
                </div>

                <!-- Statistics Cards -->
                <div class="stats-grid">
                    <div class="stat-card">
                        <div class="stat-icon blue">
                            <i class="fas fa-users"></i>
                        </div>
                        <div class="stat-number"><?php echo $total_santri; ?></div>
                        <div class="stat-label">Total Santri Aktif</div>
                    </div>
                    
                    <div class="stat-card">
                        <div class="stat-icon green">
                            <i class="fas fa-chalkboard-teacher"></i>
                        </div>
                        <div class="stat-number"><?php echo $total_guru; ?></div>
                        <div class="stat-label">Total Guru Aktif</div>
                    </div>
                    
                    <div class="stat-card">
                        <div class="stat-icon orange">
                            <i class="fas fa-school"></i>
                        </div>
                        <div class="stat-number"><?php echo $total_kelas; ?></div>
                        <div class="stat-label">Total Kelas</div>
                    </div>
                    
                    <div class="stat-card">
                        <div class="stat-icon purple">
                            <i class="fas fa-book"></i>
                        </div>
                        <div class="stat-number"><?php echo $total_mapel; ?></div>
                        <div class="stat-label">Total Mata Pelajaran</div>
                    </div>
                </div>

                <!-- Monitoring Grid -->
                <div class="monitoring-grid">
                    <!-- Absensi Hari Ini -->
                    <div class="monitoring-card">
                        <div class="card-header">
                            <h3 class="card-title">Absensi Hari Ini</h3>
                        </div>
                        <div class="card-body">
                            <?php if (!empty($absensi_per_kelas)): ?>
                            <table class="monitoring-table">
                                <thead>
                                    <tr>
                                        <th>Kelas</th>
                                        <th>Total</th>
                                        <th>Hadir</th>
                                        <th>Sakit</th>
                                        <th>Izin</th>
                                        <th>Alpha</th>
                                        <th>% Hadir</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($absensi_per_kelas as $absen): ?>
                                    <?php 
                                    $total = $absen['total_santri'];
                                    $hadir = $absen['hadir'];
                                    $persen_hadir = $total > 0 ? ($hadir / $total) * 100 : 0;
                                    ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($absen['nama_kelas']); ?></td>
                                        <td><?php echo $total; ?></td>
                                        <td><?php echo $hadir; ?></td>
                                        <td><?php echo $absen['sakit']; ?></td>
                                        <td><?php echo $absen['izin']; ?></td>
                                        <td><?php echo $absen['alpha']; ?></td>
                                        <td>
                                            <?php echo number_format($persen_hadir, 1); ?>%
                                            <div class="progress-bar">
                                                <div class="progress-fill <?php echo $persen_hadir < 80 ? 'danger' : ($persen_hadir < 90 ? 'warning' : ''); ?>" 
                                                     style="width: <?php echo $persen_hadir; ?>%"></div>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                            <?php else: ?>
                            <p style="text-align: center; color: #666; padding: 20px;">
                                <i class="fas fa-calendar-times"></i> Belum ada data absensi hari ini
                            </p>
                            <?php endif; ?>
                        </div>
                    </div>

                    <!-- Jadwal Hari Ini -->
                    <div class="monitoring-card">
                        <div class="card-header">
                            <h3 class="card-title">Jadwal Mengajar Hari Ini</h3>
                        </div>
                        <div class="card-body">
                            <?php if (!empty($jadwal_hari_ini)): ?>
                            <div class="chart-container">
                                <?php foreach ($jadwal_hari_ini as $jadwal): ?>
                                <div class="chart-item">
                                    <div>
                                        <div class="chart-label"><?php echo htmlspecialchars($jadwal['nama_mapel']); ?></div>
                                        <small><?php echo htmlspecialchars($jadwal['nama_kelas']); ?> - <?php echo htmlspecialchars($jadwal['nama_lengkap']); ?></small>
                                    </div>
                                    <div class="chart-value">
                                        <?php echo date('H:i', strtotime($jadwal['jam_mulai'])); ?> - 
                                        <?php echo date('H:i', strtotime($jadwal['jam_selesai'])); ?>
                                    </div>
                                </div>
                                <?php endforeach; ?>
                            </div>
                            <?php else: ?>
                            <p style="text-align: center; color: #666; padding: 20px;">
                                <i class="fas fa-calendar-times"></i> Tidak ada jadwal mengajar hari ini
                            </p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <!-- Additional Monitoring -->
                <div class="monitoring-grid" style="margin-top: 30px;">
                    <!-- Santri per Kamar -->
                    <div class="monitoring-card">
                        <div class="card-header">
                            <h3 class="card-title">Distribusi Santri per Kamar</h3>
                        </div>
                        <div class="card-body">
                            <div class="chart-container">
                                <?php foreach ($santri_per_kamar as $kamar): ?>
                                <div class="chart-item">
                                    <div class="chart-label"><?php echo htmlspecialchars($kamar['kamar']); ?></div>
                                    <div class="chart-value">
                                        <?php echo $kamar['jumlah']; ?> santri
                                        <div class="progress-bar">
                                            <div class="progress-fill" style="width: <?php echo ($kamar['jumlah'] / $total_santri) * 100; ?>%"></div>
                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>

                    <!-- Santri per Jenjang -->
                    <div class="monitoring-card">
                        <div class="card-header">
                            <h3 class="card-title">Distribusi Santri per Jenjang</h3>
                        </div>
                        <div class="card-body">
                            <div class="chart-container">
                                <?php foreach ($santri_per_jenjang as $jenjang): ?>
                                <div class="chart-item">
                                    <div class="chart-label"><?php echo htmlspecialchars($jenjang['jenjang_pendidikan']); ?></div>
                                    <div class="chart-value">
                                        <?php echo $jenjang['jumlah']; ?> santri
                                        <div class="progress-bar">
                                            <div class="progress-fill" style="width: <?php echo ($jenjang['jumlah'] / $total_santri) * 100; ?>%"></div>
                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="../assets/js/script.js"></script>
    <script>
        // Auto refresh every 5 minutes
        setTimeout(function() {
            location.reload();
        }, 300000);
    </script>
</body>
</html> 