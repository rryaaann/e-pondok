<?php
session_start();
require_once '../config/database.php';

// Cek login
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'operator') {
    header('Location: ../login.php');
    exit();
}

// Ambil statistik
try {
    $stmt = $pdo->query("SELECT COUNT(*) as total_santri FROM santri WHERE status_santri = 'aktif'");
    $total_santri = $stmt->fetch()['total_santri'];
    
    $stmt = $pdo->query("SELECT COUNT(*) as total_guru FROM guru WHERE status = 'aktif'");
    $total_guru = $stmt->fetch()['total_guru'];
    
    $stmt = $pdo->query("SELECT COUNT(*) as total_kelas FROM kelas");
    $total_kelas = $stmt->fetch()['total_kelas'];
    
    $stmt = $pdo->query("SELECT COUNT(*) as pending_pendaftaran FROM pendaftaran WHERE status = 'pending'");
    $pending_pendaftaran = $stmt->fetch()['pending_pendaftaran'];
    
    // Santri per kamar
    $stmt = $pdo->query("SELECT kamar, COUNT(*) as jumlah FROM santri WHERE status_santri = 'aktif' GROUP BY kamar ORDER BY jumlah DESC LIMIT 5");
    $santri_per_kamar = $stmt->fetchAll();
    
    // Pendaftaran terbaru
    $stmt = $pdo->query("SELECT * FROM pendaftaran ORDER BY created_at DESC LIMIT 5");
    $pendaftaran_terbaru = $stmt->fetchAll();
    
} catch(PDOException $e) {
    $error = "Error: " . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Operator - e-Pondok</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        .admin-container {
            display: flex;
            min-height: 100vh;
        }
        
        .sidebar {
            width: 250px;
            background: #2c5aa0;
            color: white;
            position: fixed;
            height: 100vh;
            overflow-y: auto;
        }
        
        .sidebar-header {
            padding: 20px;
            text-align: center;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }
        
        .sidebar-title {
            font-size: 1.2rem;
            font-weight: 700;
        }
        
        .sidebar-menu {
            padding: 20px 0;
        }
        
        .menu-item {
            display: block;
            padding: 15px 20px;
            color: white;
            text-decoration: none;
            transition: all 0.3s ease;
            border-left: 3px solid transparent;
        }
        
        .menu-item:hover,
        .menu-item.active {
            background: rgba(255, 255, 255, 0.1);
            border-left-color: #ff6b6b;
        }
        
        .menu-item i {
            margin-right: 10px;
            width: 20px;
        }
        
        .main-content {
            flex: 1;
            margin-left: 250px;
            background: #f8f9fa;
        }
        
        .top-bar {
            background: white;
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .page-title {
            font-size: 1.5rem;
            font-weight: 600;
            color: #2c5aa0;
        }
        
        .user-info {
            display: flex;
            align-items: center;
            gap: 15px;
        }
        
        .user-avatar {
            width: 40px;
            height: 40px;
            background: #2c5aa0;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
        }
        
        .logout-btn {
            background: #dc3545;
            color: white;
            padding: 8px 15px;
            border-radius: 5px;
            text-decoration: none;
            font-size: 0.9rem;
        }
        
        .content-area {
            padding: 30px;
        }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .stat-card {
            background: white;
            padding: 25px;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease;
        }
        
        .stat-card:hover {
            transform: translateY(-5px);
        }
        
        .stat-icon {
            width: 60px;
            height: 60px;
            border-radius: 15px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            color: white;
            margin-bottom: 15px;
        }
        
        .stat-icon.blue { background: #2c5aa0; }
        .stat-icon.green { background: #28a745; }
        .stat-icon.orange { background: #ffc107; }
        .stat-icon.red { background: #dc3545; }
        
        .stat-number {
            font-size: 2rem;
            font-weight: 700;
            color: #333;
            margin-bottom: 5px;
        }
        
        .stat-label {
            color: #666;
            font-size: 0.9rem;
        }
        
        .dashboard-grid {
            display: grid;
            grid-template-columns: 2fr 1fr;
            gap: 30px;
        }
        
        .dashboard-card {
            background: white;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            overflow: hidden;
        }
        
        .card-header {
            padding: 20px;
            background: #f8f9fa;
            border-bottom: 1px solid #e9ecef;
        }
        
        .card-title {
            font-size: 1.2rem;
            font-weight: 600;
            color: #2c5aa0;
        }
        
        .card-body {
            padding: 20px;
        }
        
        .table {
            width: 100%;
            border-collapse: collapse;
        }
        
        .table th,
        .table td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #e9ecef;
        }
        
        .table th {
            background: #f8f9fa;
            font-weight: 600;
            color: #333;
        }
        
        .status-badge {
            padding: 5px 10px;
            border-radius: 15px;
            font-size: 0.8rem;
            font-weight: 600;
        }
        
        .status-pending { background: #fff3cd; color: #856404; }
        .status-diterima { background: #d4edda; color: #155724; }
        .status-ditolak { background: #f8d7da; color: #721c24; }
        
        .quick-actions {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            margin-top: 30px;
        }
        
        .action-btn {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 15px 20px;
            background: white;
            border: 2px solid #e9ecef;
            border-radius: 10px;
            text-decoration: none;
            color: #333;
            transition: all 0.3s ease;
        }
        
        .action-btn:hover {
            border-color: #2c5aa0;
            color: #2c5aa0;
            transform: translateY(-2px);
        }
        
        .action-btn i {
            font-size: 1.2rem;
        }
        
        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
                transition: transform 0.3s ease;
            }
            
            .sidebar.active {
                transform: translateX(0);
            }
            
            .main-content {
                margin-left: 0;
            }
            
            .dashboard-grid {
                grid-template-columns: 1fr;
            }
            
            .stats-grid {
                grid-template-columns: repeat(2, 1fr);
            }
        }
    </style>
</head>
<body>
    <div class="admin-container">
        <!-- Sidebar -->
        <div class="sidebar" id="sidebar">
            <div class="sidebar-header">
                <h2 class="sidebar-title">e-Pondok</h2>
                <p>Operator Panel</p>
            </div>
            <div class="sidebar-menu">
                <a href="dashboard.php" class="menu-item active">
                    <i class="fas fa-tachometer-alt"></i> Dashboard
                </a>
                <a href="santri.php" class="menu-item">
                    <i class="fas fa-users"></i> Data Santri
                </a>
                <a href="guru.php" class="menu-item">
                    <i class="fas fa-chalkboard-teacher"></i> Data Guru
                </a>
                <a href="kelas.php" class="menu-item">
                    <i class="fas fa-school"></i> Kelas
                </a>
                <a href="mapel.php" class="menu-item">
                    <i class="fas fa-book"></i> Mata Pelajaran
                </a>
                <a href="jadwal.php" class="menu-item">
                    <i class="fas fa-calendar-alt"></i> Jadwal
                </a>
                <a href="kamar.php" class="menu-item">
                    <i class="fas fa-bed"></i> Kamar
                </a>
                <a href="pendaftaran.php" class="menu-item">
                    <i class="fas fa-user-plus"></i> Pendaftaran
                </a>
                <a href="rapot.php" class="menu-item">
                    <i class="fas fa-file-alt"></i> e-Rapot
                </a>
                <a href="monitoring.php" class="menu-item">
                    <i class="fas fa-chart-line"></i> Monitoring
                </a>
            </div>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <div class="top-bar">
                <div class="page-title">Dashboard Operator</div>
                <div class="user-info">
                    <div class="user-avatar">
                        <i class="fas fa-user"></i>
                    </div>
                    <div>
                        <div><?php echo htmlspecialchars($_SESSION['nama_lengkap']); ?></div>
                        <small>Operator</small>
                    </div>
                    <a href="../logout.php" class="logout-btn">
                        <i class="fas fa-sign-out-alt"></i> Logout
                    </a>
                </div>
            </div>

            <div class="content-area">
                <!-- Statistics Cards -->
                <div class="stats-grid">
                    <div class="stat-card">
                        <div class="stat-icon blue">
                            <i class="fas fa-users"></i>
                        </div>
                        <div class="stat-number"><?php echo $total_santri; ?></div>
                        <div class="stat-label">Total Santri Aktif</div>
                    </div>
                    
                    <div class="stat-card">
                        <div class="stat-icon green">
                            <i class="fas fa-chalkboard-teacher"></i>
                        </div>
                        <div class="stat-number"><?php echo $total_guru; ?></div>
                        <div class="stat-label">Total Guru Aktif</div>
                    </div>
                    
                    <div class="stat-card">
                        <div class="stat-icon orange">
                            <i class="fas fa-school"></i>
                        </div>
                        <div class="stat-number"><?php echo $total_kelas; ?></div>
                        <div class="stat-label">Total Kelas</div>
                    </div>
                    
                    <div class="stat-card">
                        <div class="stat-icon red">
                            <i class="fas fa-user-plus"></i>
                        </div>
                        <div class="stat-number"><?php echo $pending_pendaftaran; ?></div>
                        <div class="stat-label">Pendaftaran Pending</div>
                    </div>
                </div>

                <!-- Dashboard Grid -->
                <div class="dashboard-grid">
                    <div class="dashboard-card">
                        <div class="card-header">
                            <h3 class="card-title">Pendaftaran Terbaru</h3>
                        </div>
                        <div class="card-body">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>Nama</th>
                                        <th>Jenis Santri</th>
                                        <th>Jenjang</th>
                                        <th>Status</th>
                                        <th>Tanggal</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($pendaftaran_terbaru as $pendaftaran): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($pendaftaran['nama_lengkap']); ?></td>
                                        <td><?php echo htmlspecialchars($pendaftaran['jenis_santri']); ?></td>
                                        <td><?php echo htmlspecialchars($pendaftaran['jenjang_pendidikan']); ?></td>
                                        <td>
                                            <span class="status-badge status-<?php echo $pendaftaran['status']; ?>">
                                                <?php echo ucfirst($pendaftaran['status']); ?>
                                            </span>
                                        </td>
                                        <td><?php echo date('d/m/Y', strtotime($pendaftaran['created_at'])); ?></td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>

                    <div class="dashboard-card">
                        <div class="card-header">
                            <h3 class="card-title">Santri per Kamar</h3>
                        </div>
                        <div class="card-body">
                            <?php foreach ($santri_per_kamar as $kamar): ?>
                            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">
                                <span><?php echo htmlspecialchars($kamar['kamar']); ?></span>
                                <span style="background: #2c5aa0; color: white; padding: 5px 10px; border-radius: 15px; font-size: 0.9rem;">
                                    <?php echo $kamar['jumlah']; ?> santri
                                </span>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>

                <!-- Quick Actions -->
                <div class="quick-actions">
                    <a href="santri.php?action=add" class="action-btn">
                        <i class="fas fa-user-plus"></i>
                        <div>
                            <div>Tambah Santri</div>
                            <small>Input data santri baru</small>
                        </div>
                    </a>
                    
                    <a href="guru.php?action=add" class="action-btn">
                        <i class="fas fa-chalkboard-teacher"></i>
                        <div>
                            <div>Tambah Guru</div>
                            <small>Input data guru baru</small>
                        </div>
                    </a>
                    
                    <a href="kelas.php?action=add" class="action-btn">
                        <i class="fas fa-school"></i>
                        <div>
                            <div>Buat Kelas</div>
                            <small>Buat kelas baru</small>
                        </div>
                    </a>
                    
                    <a href="pendaftaran.php" class="action-btn">
                        <i class="fas fa-user-check"></i>
                        <div>
                            <div>Review Pendaftaran</div>
                            <small>Terima/tolak pendaftaran</small>
                        </div>
                    </a>
                    
                    <a href="jadwal.php" class="action-btn">
                        <i class="fas fa-calendar-alt"></i>
                        <div>
                            <div>Kelola Jadwal</div>
                            <small>Atur jadwal pelajaran</small>
                        </div>
                    </a>
                    
                    <a href="rapot.php" class="action-btn">
                        <i class="fas fa-file-alt"></i>
                        <div>
                            <div>e-Rapot</div>
                            <small>Kelola nilai santri</small>
                        </div>
                    </a>
                </div>
            </div>
        </div>
    </div>

    <script src="../assets/js/script.js"></script>
</body>
</html> 