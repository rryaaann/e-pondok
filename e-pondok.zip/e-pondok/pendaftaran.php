<?php
session_start();
require_once 'config/database.php';

$success = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nama_lengkap = trim($_POST['nama_lengkap']);
    $nik = trim($_POST['nik']);
    $nisn = trim($_POST['nisn']);
    $tempat_lahir = trim($_POST['tempat_lahir']);
    $tanggal_lahir = $_POST['tanggal_lahir'];
    $jenis_kelamin = $_POST['jenis_kelamin'];
    $alamat = trim($_POST['alamat']);
    $jenis_santri = $_POST['jenis_santri'];
    $jenjang_pendidikan = $_POST['jenjang_pendidikan'];
    $nama_wali = trim($_POST['nama_wali']);
    $no_hp_wali = trim($_POST['no_hp_wali']);
    
    // Validasi
    if (empty($nama_lengkap) || empty($nik) || empty($tempat_lahir) || empty($tanggal_lahir) || 
        empty($alamat) || empty($nama_wali) || empty($no_hp_wali)) {
        $error = 'Semua field wajib diisi!';
    } elseif (strlen($nik) != 16) {
        $error = 'NIK harus 16 digit!';
    } elseif (!empty($nisn) && strlen($nisn) != 10) {
        $error = 'NISN harus 10 digit!';
    } else {
        try {
            // Upload file
            $file_ijazah = '';
            $file_kk = '';
            
            if (isset($_FILES['file_ijazah']) && $_FILES['file_ijazah']['error'] == 0) {
                $allowed = ['pdf', 'jpg', 'jpeg', 'png'];
                $filename = $_FILES['file_ijazah']['name'];
                $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
                
                if (in_array($ext, $allowed)) {
                    $newname = 'ijazah_' . time() . '.' . $ext;
                    $upload_path = 'uploads/' . $newname;
                    
                    if (move_uploaded_file($_FILES['file_ijazah']['tmp_name'], $upload_path)) {
                        $file_ijazah = $upload_path;
                    }
                }
            }
            
            if (isset($_FILES['file_kk']) && $_FILES['file_kk']['error'] == 0) {
                $allowed = ['pdf', 'jpg', 'jpeg', 'png'];
                $filename = $_FILES['file_kk']['name'];
                $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
                
                if (in_array($ext, $allowed)) {
                    $newname = 'kk_' . time() . '.' . $ext;
                    $upload_path = 'uploads/' . $newname;
                    
                    if (move_uploaded_file($_FILES['file_kk']['tmp_name'], $upload_path)) {
                        $file_kk = $upload_path;
                    }
                }
            }
            
            // Insert ke database
            $stmt = $pdo->prepare("INSERT INTO pendaftaran (nama_lengkap, nik, nisn, tempat_lahir, tanggal_lahir, 
                                  jenis_kelamin, alamat, jenis_santri, jenjang_pendidikan, nama_wali, no_hp_wali, 
                                  file_ijazah, file_kk) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            
            $stmt->execute([$nama_lengkap, $nik, $nisn, $tempat_lahir, $tanggal_lahir, $jenis_kelamin, 
                          $alamat, $jenis_santri, $jenjang_pendidikan, $nama_wali, $no_hp_wali, 
                          $file_ijazah, $file_kk]);
            
            $success = 'Pendaftaran berhasil! Data Anda telah kami terima dan sedang dalam proses review.';
            
            // Reset form
            $_POST = array();
            
        } catch(PDOException $e) {
            $error = 'Terjadi kesalahan sistem! Silakan coba lagi.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pendaftaran Santri - e-Pondok</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        .registration-container {
            padding: 120px 0 80px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
        }
        
        .registration-card {
            background: white;
            border-radius: 20px;
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            max-width: 800px;
            margin: 0 auto;
        }
        
        .registration-header {
            background: linear-gradient(135deg, #2c5aa0 0%, #1e3f7a 100%);
            color: white;
            padding: 30px;
            text-align: center;
        }
        
        .registration-title {
            font-size: 2rem;
            font-weight: 700;
            margin-bottom: 10px;
        }
        
        .registration-subtitle {
            opacity: 0.9;
        }
        
        .registration-body {
            padding: 40px;
        }
        
        .form-section {
            margin-bottom: 30px;
        }
        
        .section-title {
            font-size: 1.3rem;
            font-weight: 600;
            color: #2c5aa0;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 2px solid #e1e5e9;
        }
        
        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #333;
        }
        
        .form-label.required::after {
            content: ' *';
            color: #dc3545;
        }
        
        .form-control {
            width: 100%;
            padding: 12px 15px;
            border: 2px solid #e1e5e9;
            border-radius: 8px;
            font-size: 1rem;
            transition: all 0.3s ease;
        }
        
        .form-control:focus {
            outline: none;
            border-color: #2c5aa0;
            box-shadow: 0 0 0 3px rgba(44, 90, 160, 0.1);
        }
        
        .form-control.error {
            border-color: #dc3545;
        }
        
        .file-upload {
            position: relative;
            display: inline-block;
            width: 100%;
        }
        
        .file-upload input[type=file] {
            position: absolute;
            left: -9999px;
        }
        
        .file-upload-label {
            display: block;
            padding: 12px 15px;
            border: 2px dashed #e1e5e9;
            border-radius: 8px;
            text-align: center;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        .file-upload-label:hover {
            border-color: #2c5aa0;
            background: #f8f9fa;
        }
        
        .file-preview {
            margin-top: 10px;
            padding: 10px;
            background: #f8f9fa;
            border-radius: 8px;
            font-size: 0.9rem;
        }
        
        .btn-submit {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 15px 30px;
            border: none;
            border-radius: 10px;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            width: 100%;
        }
        
        .btn-submit:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 25px rgba(102, 126, 234, 0.3);
        }
        
        .alert {
            padding: 15px;
            border-radius: 10px;
            margin-bottom: 20px;
            font-weight: 500;
        }
        
        .alert-success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        
        .alert-danger {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        
        .progress-bar {
            display: flex;
            justify-content: space-between;
            margin-bottom: 30px;
            position: relative;
        }
        
        .progress-step {
            flex: 1;
            text-align: center;
            position: relative;
        }
        
        .progress-step::before {
            content: '';
            position: absolute;
            top: 15px;
            left: 50%;
            width: 30px;
            height: 30px;
            background: #e1e5e9;
            border-radius: 50%;
            transform: translateX(-50%);
            z-index: 1;
        }
        
        .progress-step.active::before {
            background: #2c5aa0;
        }
        
        .progress-step.completed::before {
            background: #28a745;
        }
        
        .progress-step::after {
            content: '';
            position: absolute;
            top: 30px;
            left: 0;
            width: 100%;
            height: 2px;
            background: #e1e5e9;
        }
        
        .progress-step:last-child::after {
            display: none;
        }
        
        .progress-step.completed::after {
            background: #28a745;
        }
        
        .step-label {
            margin-top: 40px;
            font-size: 0.9rem;
            font-weight: 600;
            color: #666;
        }
        
        .step-label.active {
            color: #2c5aa0;
        }
        
        .step-label.completed {
            color: #28a745;
        }
        
        @media (max-width: 768px) {
            .form-row {
                grid-template-columns: 1fr;
            }
            
            .registration-body {
                padding: 20px;
            }
            
            .registration-header {
                padding: 20px;
            }
            
            .registration-title {
                font-size: 1.5rem;
            }
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar">
        <div class="nav-container">
            <div class="nav-logo">
                <img src="assets/images/logo.png" alt="e-Pondok Logo" class="logo-img">
                <span class="logo-text">e-Pondok</span>
            </div>
            <div class="nav-menu" id="nav-menu">
                <a href="index.php" class="nav-link">Beranda</a>
                <a href="index.php#profil" class="nav-link">Profil Pondok</a>
                <a href="index.php#kegiatan" class="nav-link">Kegiatan</a>
                <a href="pendaftaran.php" class="nav-link">Pendaftaran</a>
                <a href="login.php" class="nav-link btn-login">Login</a>
            </div>
            <div class="nav-toggle" id="nav-toggle">
                <span class="bar"></span>
                <span class="bar"></span>
                <span class="bar"></span>
            </div>
        </div>
    </nav>

    <div class="registration-container">
        <div class="container">
            <div class="registration-card">
                <div class="registration-header">
                    <h1 class="registration-title">Pendaftaran Santri Baru</h1>
                    <p class="registration-subtitle">Tahun Ajaran 2025/2026</p>
                </div>
                
                <div class="registration-body">
                    <?php if ($success): ?>
                        <div class="alert alert-success">
                            <i class="fas fa-check-circle"></i> <?php echo $success; ?>
                        </div>
                    <?php endif; ?>
                    
                    <?php if ($error): ?>
                        <div class="alert alert-danger">
                            <i class="fas fa-exclamation-triangle"></i> <?php echo $error; ?>
                        </div>
                    <?php endif; ?>
                    
                    <div class="progress-bar">
                        <div class="progress-step active">
                            <div class="step-label active">Data Pribadi</div>
                        </div>
                        <div class="progress-step">
                            <div class="step-label">Data Akademik</div>
                        </div>
                        <div class="progress-step">
                            <div class="step-label">Data Wali</div>
                        </div>
                        <div class="progress-step">
                            <div class="step-label">Berkas</div>
                        </div>
                    </div>
                    
                    <form method="POST" action="" enctype="multipart/form-data">
                        <!-- Data Pribadi -->
                        <div class="form-section">
                            <h3 class="section-title">Data Pribadi</h3>
                            <div class="form-row">
                                <div class="form-group">
                                    <label for="nama_lengkap" class="form-label required">Nama Lengkap</label>
                                    <input type="text" id="nama_lengkap" name="nama_lengkap" class="form-control" required
                                           value="<?php echo isset($_POST['nama_lengkap']) ? htmlspecialchars($_POST['nama_lengkap']) : ''; ?>">
                                </div>
                                <div class="form-group">
                                    <label for="jenis_kelamin" class="form-label required">Jenis Kelamin</label>
                                    <select id="jenis_kelamin" name="jenis_kelamin" class="form-control" required>
                                        <option value="">Pilih Jenis Kelamin</option>
                                        <option value="L" <?php echo (isset($_POST['jenis_kelamin']) && $_POST['jenis_kelamin'] == 'L') ? 'selected' : ''; ?>>Laki-laki</option>
                                        <option value="P" <?php echo (isset($_POST['jenis_kelamin']) && $_POST['jenis_kelamin'] == 'P') ? 'selected' : ''; ?>>Perempuan</option>
                                    </select>
                                </div>
                            </div>
                            
                            <div class="form-row">
                                <div class="form-group">
                                    <label for="nik" class="form-label required">NIK</label>
                                    <input type="text" id="nik" name="nik" class="form-control" required maxlength="16"
                                           value="<?php echo isset($_POST['nik']) ? htmlspecialchars($_POST['nik']) : ''; ?>">
                                </div>
                                <div class="form-group">
                                    <label for="nisn" class="form-label">NISN (Opsional)</label>
                                    <input type="text" id="nisn" name="nisn" class="form-control" maxlength="10"
                                           value="<?php echo isset($_POST['nisn']) ? htmlspecialchars($_POST['nisn']) : ''; ?>">
                                </div>
                            </div>
                            
                            <div class="form-row">
                                <div class="form-group">
                                    <label for="tempat_lahir" class="form-label required">Tempat Lahir</label>
                                    <input type="text" id="tempat_lahir" name="tempat_lahir" class="form-control" required
                                           value="<?php echo isset($_POST['tempat_lahir']) ? htmlspecialchars($_POST['tempat_lahir']) : ''; ?>">
                                </div>
                                <div class="form-group">
                                    <label for="tanggal_lahir" class="form-label required">Tanggal Lahir</label>
                                    <input type="date" id="tanggal_lahir" name="tanggal_lahir" class="form-control" required
                                           value="<?php echo isset($_POST['tanggal_lahir']) ? $_POST['tanggal_lahir'] : ''; ?>">
                                </div>
                            </div>
                            
                            <div class="form-group">
                                <label for="alamat" class="form-label required">Alamat Lengkap</label>
                                <textarea id="alamat" name="alamat" class="form-control" rows="3" required><?php echo isset($_POST['alamat']) ? htmlspecialchars($_POST['alamat']) : ''; ?></textarea>
                            </div>
                        </div>
                        
                        <!-- Data Akademik -->
                        <div class="form-section">
                            <h3 class="section-title">Data Akademik</h3>
                            <div class="form-row">
                                <div class="form-group">
                                    <label for="jenis_santri" class="form-label required">Jenis Santri</label>
                                    <select id="jenis_santri" name="jenis_santri" class="form-control" required>
                                        <option value="">Pilih Jenis Santri</option>
                                        <option value="Pondok Kitab" <?php echo (isset($_POST['jenis_santri']) && $_POST['jenis_santri'] == 'Pondok Kitab') ? 'selected' : ''; ?>>Pondok Kitab</option>
                                        <option value="Qurani" <?php echo (isset($_POST['jenis_santri']) && $_POST['jenis_santri'] == 'Qurani') ? 'selected' : ''; ?>>Qurani</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="jenjang_pendidikan" class="form-label required">Jenjang Pendidikan</label>
                                    <select id="jenjang_pendidikan" name="jenjang_pendidikan" class="form-control" required>
                                        <option value="">Pilih Jenjang</option>
                                        <option value="SMP" <?php echo (isset($_POST['jenjang_pendidikan']) && $_POST['jenjang_pendidikan'] == 'SMP') ? 'selected' : ''; ?>>SMP</option>
                                        <option value="SMK" <?php echo (isset($_POST['jenjang_pendidikan']) && $_POST['jenjang_pendidikan'] == 'SMK') ? 'selected' : ''; ?>>SMK</option>
                                        <option value="Tidak mengikuti" <?php echo (isset($_POST['jenjang_pendidikan']) && $_POST['jenjang_pendidikan'] == 'Tidak mengikuti') ? 'selected' : ''; ?>>Tidak mengikuti</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Data Wali -->
                        <div class="form-section">
                            <h3 class="section-title">Data Wali</h3>
                            <div class="form-row">
                                <div class="form-group">
                                    <label for="nama_wali" class="form-label required">Nama Wali</label>
                                    <input type="text" id="nama_wali" name="nama_wali" class="form-control" required
                                           value="<?php echo isset($_POST['nama_wali']) ? htmlspecialchars($_POST['nama_wali']) : ''; ?>">
                                </div>
                                <div class="form-group">
                                    <label for="no_hp_wali" class="form-label required">No. HP Wali</label>
                                    <input type="text" id="no_hp_wali" name="no_hp_wali" class="form-control" required
                                           value="<?php echo isset($_POST['no_hp_wali']) ? htmlspecialchars($_POST['no_hp_wali']) : ''; ?>">
                                </div>
                            </div>
                        </div>
                        
                        <!-- Berkas -->
                        <div class="form-section">
                            <h3 class="section-title">Upload Berkas</h3>
                            <div class="form-row">
                                <div class="form-group">
                                    <label for="file_ijazah" class="form-label">Ijazah Terakhir (PDF/JPG/PNG)</label>
                                    <div class="file-upload">
                                        <label for="file_ijazah" class="file-upload-label">
                                            <i class="fas fa-upload"></i> Pilih File Ijazah
                                        </label>
                                        <input type="file" id="file_ijazah" name="file_ijazah" accept=".pdf,.jpg,.jpeg,.png">
                                        <div class="file-preview" id="ijazah-preview"></div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="file_kk" class="form-label">Kartu Keluarga (PDF/JPG/PNG)</label>
                                    <div class="file-upload">
                                        <label for="file_kk" class="file-upload-label">
                                            <i class="fas fa-upload"></i> Pilih File KK
                                        </label>
                                        <input type="file" id="file_kk" name="file_kk" accept=".pdf,.jpg,.jpeg,.png">
                                        <div class="file-preview" id="kk-preview"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <button type="submit" class="btn-submit">
                            <i class="fas fa-paper-plane"></i> Kirim Pendaftaran
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script src="assets/js/script.js"></script>
    <script>
        // File upload preview
        document.getElementById('file_ijazah').addEventListener('change', function() {
            const file = this.files[0];
            const preview = document.getElementById('ijazah-preview');
            
            if (file) {
                preview.innerHTML = `<p><i class="fas fa-file"></i> ${file.name}</p>`;
            } else {
                preview.innerHTML = '';
            }
        });
        
        document.getElementById('file_kk').addEventListener('change', function() {
            const file = this.files[0];
            const preview = document.getElementById('kk-preview');
            
            if (file) {
                preview.innerHTML = `<p><i class="fas fa-file"></i> ${file.name}</p>`;
            } else {
                preview.innerHTML = '';
            }
        });
    </script>
</body>
</html> 