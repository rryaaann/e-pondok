<?php
session_start();
require_once 'config/database.php';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>e-Pondok - Sistem Informasi Pesantren Modern</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar">
        <div class="nav-container">
            <div class="nav-logo">
                <img src="assets/images/logo.png" alt="e-Pondok Logo" class="logo-img">
                <span class="logo-text">e-Pondok</span>
            </div>
            <div class="nav-menu" id="nav-menu">
                <a href="#beranda" class="nav-link">Beranda</a>
                <a href="#profil" class="nav-link">Profil Pondok</a>
                <a href="#kegiatan" class="nav-link">Kegiatan</a>
                <a href="pendaftaran.php" class="nav-link">Pendaftaran</a>
                <a href="login.php" class="nav-link btn-login">Login</a>
            </div>
            <div class="nav-toggle" id="nav-toggle">
                <span class="bar"></span>
                <span class="bar"></span>
                <span class="bar"></span>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <section id="beranda" class="hero">
        <div class="hero-container">
            <div class="hero-content">
                <h1 class="hero-title">Selamat Datang di e-Pondok</h1>
                <p class="hero-subtitle">Sistem Informasi Pesantren Modern untuk Pengelolaan Santri, Guru, dan Kegiatan Belajar Mengajar</p>
                <div class="hero-buttons">
                    <a href="pendaftaran.php" class="btn btn-primary">Daftar Sekarang</a>
                    <a href="#profil" class="btn btn-secondary">Pelajari Lebih Lanjut</a>
                </div>
            </div>
            <div class="hero-image">
                <img src="assets/images/hero-image.jpg" alt="Pondok Pesantren">
            </div>
        </div>
    </section>

    <!-- Profil Pondok Section -->
    <section id="profil" class="section">
        <div class="container">
            <h2 class="section-title">Profil Pondok</h2>
            <div class="profile-grid">
                <div class="profile-card">
                    <div class="card-icon">
                        <i class="fas fa-mosque"></i>
                    </div>
                    <h3>Visi</h3>
                    <p>Menjadi pondok pesantren unggulan yang menghasilkan santri berakhlak mulia, berwawasan luas, dan siap menghadapi tantangan global.</p>
                </div>
                <div class="profile-card">
                    <div class="card-icon">
                        <i class="fas fa-bullseye"></i>
                    </div>
                    <h3>Misi</h3>
                    <p>Mendidik santri dengan sistem pembelajaran terpadu yang mengintegrasikan ilmu agama dan ilmu umum.</p>
                </div>
                <div class="profile-card">
                    <div class="card-icon">
                        <i class="fas fa-users"></i>
                    </div>
                    <h3>Program Unggulan</h3>
                    <p>Tahfidz Al-Qur'an, Bahasa Arab & Inggris, Teknologi Informasi, dan Pengembangan Karakter.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Biodata Section -->
    <section class="section bg-light">
        <div class="container">
            <h2 class="section-title">Biodata Pondok</h2>
            <div class="biodata-content">
                <div class="biodata-text">
                    <h3>Pondok Pesantren Modern</h3>
                    <p><strong>Alamat:</strong> Jl. Pesantren No. 123, Kecamatan Pesantren, Kabupaten Pesantren</p>
                    <p><strong>Telepon:</strong> (021) 1234-5678</p>
                    <p><strong>Email:</strong> info@epondok.id</p>
                    <p><strong>Website:</strong> www.epondok.id</p>
                    <p><strong>Tahun Berdiri:</strong> 1990</p>
                    <p><strong>Jumlah Santri:</strong> 500+ santri</p>
                    <p><strong>Jumlah Guru:</strong> 50+ guru</p>
                </div>
                <div class="biodata-image">
                    <img src="assets/images/pondok-building.jpg" alt="Gedung Pondok">
                </div>
            </div>
        </div>
    </section>

    <!-- Kegiatan Section -->
    <section id="kegiatan" class="section">
        <div class="container">
            <h2 class="section-title">Kegiatan Pondok</h2>
            <div class="activities-grid">
                <div class="activity-card">
                    <img src="assets/images/kegiatan-ngaji.jpg" alt="Kegiatan Ngaji">
                    <div class="activity-content">
                        <h3>Kegiatan Ngaji</h3>
                        <p>Program tahfidz Al-Qur'an dan pembelajaran kitab kuning</p>
                        <span class="activity-time">06:00 - 08:00</span>
                    </div>
                </div>
                <div class="activity-card">
                    <img src="assets/images/kegiatan-sekolah.jpg" alt="Kegiatan Sekolah">
                    <div class="activity-content">
                        <h3>Kegiatan Sekolah</h3>
                        <p>Pembelajaran formal SMP dan SMK dengan kurikulum terpadu</p>
                        <span class="activity-time">08:00 - 15:00</span>
                    </div>
                </div>
                <div class="activity-card">
                    <img src="assets/images/kegiatan-ekstra.jpg" alt="Kegiatan Ekstrakurikuler">
                    <div class="activity-content">
                        <h3>Ekstrakurikuler</h3>
                        <p>Kegiatan tambahan seperti komputer, bahasa, dan olahraga</p>
                        <span class="activity-time">15:30 - 17:30</span>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Brosur Section -->
    <section class="section bg-light">
        <div class="container">
            <h2 class="section-title">Brosur Pondok</h2>
            <div class="brochure-container">
                <div class="brochure-item">
                    <img src="assets/images/brosur-1.jpg" alt="Brosur Pendaftaran">
                    <h3>Brosur Pendaftaran 2025</h3>
                    <a href="assets/brosur/brosur-2025.pdf" class="btn btn-primary" download>Download Brosur</a>
                </div>
                <div class="brochure-item">
                    <img src="assets/images/brosur-2.jpg" alt="Profil Pondok">
                    <h3>Profil Lengkap Pondok</h3>
                    <a href="assets/brosur/profil-pondok.pdf" class="btn btn-primary" download>Download Profil</a>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="footer-content">
                <div class="footer-section">
                    <h3>e-Pondok</h3>
                    <p>Sistem Informasi Pesantren Modern</p>
                    <div class="social-links">
                        <a href="#"><i class="fab fa-facebook"></i></a>
                        <a href="#"><i class="fab fa-instagram"></i></a>
                        <a href="#"><i class="fab fa-youtube"></i></a>
                    </div>
                </div>
                <div class="footer-section">
                    <h3>Kontak</h3>
                    <p><i class="fas fa-phone"></i> (021) 1234-5678</p>
                    <p><i class="fas fa-envelope"></i> info@epondok.id</p>
                    <p><i class="fas fa-map-marker-alt"></i> Jl. Pesantren No. 123</p>
                </div>
                <div class="footer-section">
                    <h3>Link Cepat</h3>
                    <ul>
                        <li><a href="pendaftaran.php">Pendaftaran</a></li>
                        <li><a href="login.php">Login</a></li>
                        <li><a href="#profil">Profil</a></li>
                        <li><a href="#kegiatan">Kegiatan</a></li>
                    </ul>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; 2025 e-Pondok. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <script src="assets/js/script.js"></script>
</body>
</html> 